"""
FFmpeg processor — async, with live progress.

- Speed 1.02× (video + audio, pitch kept)
- Logo slides in top-right at 2s, slides out at 5s, repeats every 20s
- Ending (image or video) overlaid across the bottom for the last 3 seconds, scaled to the video's width
- H.264 CRF 18 + AAC 192k, faststart. Preset is `veryfast` by default (≈2× quicker than `fast`
  at the same visual quality; files are a little larger). Change with FFMPEG_PRESET in .env.
"""
import asyncio
import json
import logging
import os

import config

log = logging.getLogger(__name__)

LOGO_WIDTH_FRAC = 120 / 1080     # logo width relative to video width
LOGO_PAD_FRAC   = 20 / 1080
LOGO_POP_IN     = 2.0
LOGO_DURATION   = 3.0
LOGO_LOOP_EVERY = 20.0
LOGO_SLIDE      = 0.25           # seconds for slide in / out
ENDING_DURATION = 3.0


def _is_video(path: str) -> bool:
    return os.path.splitext(path)[1].lower() in config.VIDEO_EXTS


async def _run(*cmd: str) -> tuple[int, str, str]:
    proc = await asyncio.create_subprocess_exec(
        *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    out, err = await proc.communicate()
    return proc.returncode, out.decode(errors="replace"), err.decode(errors="replace")


async def probe(path: str) -> dict:
    code, out, err = await _run(
        "ffprobe", "-v", "error", "-print_format", "json",
        "-show_entries", "format=duration:stream=codec_type,width,height:stream_tags=rotate"
                         ":stream_side_data=rotation", path)
    if code != 0:
        raise RuntimeError(f"Could not read video: {err.strip()[-300:]}")
    info = json.loads(out or "{}")
    streams = info.get("streams", [])
    video = next((s for s in streams if s.get("codec_type") == "video"), None)
    if not video:
        raise RuntimeError("That file has no video stream.")
    width, height = int(video["width"]), int(video["height"])
    rotation = 0
    try:
        rotation = int(float(video.get("tags", {}).get("rotate", 0)))
        for sd in video.get("side_data_list", []):
            if "rotation" in sd:
                rotation = int(float(sd["rotation"]))
    except (TypeError, ValueError):
        pass
    if abs(rotation) % 180 == 90:
        width, height = height, width
    return {
        "duration": float(info.get("format", {}).get("duration") or 0),
        "width": width, "height": height,
        "has_audio": any(s.get("codec_type") == "audio" for s in streams),
    }


def _even(n: float) -> int:
    return max(2, int(n) // 2 * 2)


def build_command(input_path: str, output_path: str, meta: dict,
                  logo: str | None, ending: str | None, speed: float,
                  contrast: float = 1.0, logo_position: str = "top-right") -> list[str]:
    out_duration = meta["duration"] / speed
    width = meta["width"]

    # Nothing to change → remux only (instant).
    if not logo and not ending and abs(speed - 1.0) < 1e-6 and abs(contrast - 1.0) < 1e-6:
        return ["ffmpeg", "-y", "-v", "error", "-nostats", "-progress", "pipe:1", "-i", input_path,
                "-c", "copy", "-movflags", "+faststart", output_path]

    cmd = ["ffmpeg", "-y", "-v", "error", "-nostats", "-progress", "pipe:1", "-i", input_path]
    parts = [f"[0:v]setpts=PTS/{speed},scale=trunc(iw/2)*2:trunc(ih/2)*2,eq=contrast={contrast:.3f}[v0]"]
    last, idx = "[v0]", 1

    if logo:
        cmd += ["-i", logo]
        lw, pad = _even(width * LOGO_WIDTH_FRAC), max(4, int(width * LOGO_PAD_FRAC))
        phase = f"mod(t,{LOGO_LOOP_EVERY})"
        a, b = LOGO_POP_IN, LOGO_POP_IN + LOGO_DURATION
        # y slides from above the frame down to `pad`, then back up.
        y = (f"{pad}-(h+{pad})*(max(0,1-({phase}-{a})/{LOGO_SLIDE})"
             f"+max(0,({phase}-{b - LOGO_SLIDE})/{LOGO_SLIDE}))")
        parts.append(f"[{idx}:v]scale={lw}:-1[lg]")
        x = str(pad) if logo_position.endswith("left") else f"W-w-{pad}"
        if logo_position.startswith("bottom"):
            y = f"H-h-{pad}"
        parts.append(f"{last}[lg]overlay=x={x}:y='{y}':enable='between({phase},{a},{b})'[v1]")
        last, idx = "[v1]", idx + 1

    if ending:
        start = max(0.0, out_duration - ENDING_DURATION)
        if _is_video(ending):
            cmd += ["-stream_loop", "-1", "-t", f"{ENDING_DURATION}", "-i", ending]
            parts.append(f"[{idx}:v]scale={_even(width)}:-2,setpts=PTS-STARTPTS+{start:.3f}/TB[en]")
            parts.append(f"{last}[en]overlay=x=0:y=H-h:eof_action=pass:enable='gte(t,{start:.3f})'[v2]")
        else:
            cmd += ["-i", ending]
            parts.append(f"[{idx}:v]scale={_even(width)}:-2[en]")
            parts.append(f"{last}[en]overlay=x=0:y=H-h:enable='gte(t,{start:.3f})'[v2]")
        last = "[v2]"

    maps = ["-map", last]
    if meta["has_audio"]:
        parts.append(f"[0:a]atempo={speed}[a0]")
        maps += ["-map", "[a0]", "-c:a", "aac", "-b:a", "192k"]

    cmd += ["-filter_complex", ";".join(parts), *maps,
            "-c:v", "libx264", "-preset", config.FFMPEG_PRESET, "-crf", config.FFMPEG_CRF,
            "-pix_fmt", "yuv420p", "-threads", "2", "-max_muxing_queue_size", "1024",
            "-t", f"{out_duration:.3f}", "-movflags", "+faststart", output_path]
    return cmd


class VideoProcessor:
    async def process(self, input_path: str, output_path: str,
                      logo_path: str | None = None, ending_path: str | None = None,
                      speed: float | None = None, contrast: float = 1.0,
                      logo_position: str = "top-right", on_progress=None) -> dict:
        speed = speed or config.SPEED
        meta = await probe(input_path)
        cmd = build_command(input_path, output_path, meta, logo_path, ending_path, speed,
                            contrast, logo_position)
        log.info("FFmpeg start: %.1fs %dx%d → %s", meta["duration"], meta["width"], meta["height"], output_path)

        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        err_task = asyncio.create_task(proc.stderr.read())
        total_us = max(1.0, meta["duration"] / speed * 1_000_000)
        last = -1
        try:
            async for raw in proc.stdout:
                line = raw.decode(errors="replace").strip()
                if line.startswith("out_time_us=") or line.startswith("out_time_ms="):
                    try:
                        pct = min(99, int(int(line.split("=", 1)[1]) / total_us * 100))
                    except ValueError:
                        continue
                    if on_progress and pct > last:
                        last = pct
                        await on_progress(pct)
            code = await proc.wait()
        except asyncio.CancelledError:
            proc.kill()
            raise
        err = (await err_task).decode(errors="replace")
        if code != 0:
            raise RuntimeError(f"FFmpeg failed: {err.strip()[-600:]}")
        if on_progress:
            await on_progress(100)
        return meta

    async def frames(self, input_path: str, count: int = 4) -> list[bytes]:
        """A few small JPEG stills, used to let the AI look at the video."""
        meta = await probe(input_path)
        out = []
        for i in range(count):
            t = meta["duration"] * (i + 0.5) / count
            proc = await asyncio.create_subprocess_exec(
                "ffmpeg", "-v", "error", "-ss", f"{t:.2f}", "-i", input_path, "-frames:v", "1",
                "-vf", "scale=360:-2", "-q:v", "7", "-f", "image2pipe", "-vcodec", "mjpeg", "pipe:1",
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL)
            data, _ = await proc.communicate()
            if data:
                out.append(data)
        return out
