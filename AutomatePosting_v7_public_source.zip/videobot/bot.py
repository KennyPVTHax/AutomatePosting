"""
Telegram front-end. Owner-only.

Send a video → one card with everything on it (preset already filled in) → Post now / Next slot.
With Autopilot on there are no taps at all: the video is queued for the next free slot,
captioned and posted on its own, and this chat gets the links.
"""
import html
import logging
import os
import time

from telegram import BotCommand, InlineKeyboardButton as Btn, InlineKeyboardMarkup as Kb, Update
from telegram.constants import ParseMode
from telegram.error import BadRequest, TelegramError
from telegram.ext import (Application, CallbackQueryHandler, CommandHandler, ContextTypes,
                          MessageHandler, filters)

import captions
import channel_manager as cm
import config
from pipeline import Pipeline, fmt_time
from store import ACTIVE

log = logging.getLogger(__name__)
esc = html.escape

MODES = {"ai": "🤖 AI", "template": "🧩 Template", "manual": "✍️ My own text", "none": "🚫 No caption"}
STATUS_ICON = {"draft": "📝", "scheduled": "🕒", "processing": "⚙️", "posting": "📤",
               "done": "✅", "partial": "⚠️", "failed": "❌", "cancelled": "✖️"}
TARGET_ICON = {"pending": "▫️", "posting": "⏳", "ok": "✅", "failed": "❌"}


def owner_only(fn):
    async def wrapper(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not update.effective_user or update.effective_user.id != config.OWNER_ID:
            return
        return await fn(update, ctx)
    return wrapper


def bar(pct: int) -> str:
    filled = max(0, min(10, round(pct / 10)))
    return "▰" * filled + "▱" * (10 - filled)


class Bot:
    def __init__(self, pipeline: Pipeline):
        self.p = pipeline
        self.store = pipeline.store
        builder = Application.builder().token(config.BOT_TOKEN).concurrent_updates(True)
        if config.TELEGRAM_API_URL:                # self-hosted Bot API server: files up to 2 GB
            base = config.TELEGRAM_API_URL.rstrip("/")
            builder = builder.base_url(f"{base}/bot").base_file_url(f"{base}/file/bot").local_mode(True)
        self.app = builder.build()
        self._register()
        pipeline.listeners.append(self.on_job_update)
        pipeline.notifiers.append(self.notify)

    def _register(self):
        add = self.app.add_handler
        for name, fn in [("start", self.cmd_start), ("help", self.cmd_start), ("queue", self.cmd_queue),
                         ("autopilot", self.cmd_autopilot), ("slots", self.cmd_slots),
                         ("episode", self.cmd_episode), ("channels", self.cmd_channels),
                         ("addyt", self.cmd_addyt), ("addig", self.cmd_addig), ("addfb", self.cmd_addfb),
                         ("assets", self.cmd_assets), ("deletelogo", self.cmd_delete_logo),
                         ("deleteending", self.cmd_delete_ending), ("dashboard", self.cmd_dashboard),
                         ("cancel", self.cmd_cancel)]:
            add(CommandHandler(name, owner_only(fn)))
        add(MessageHandler(filters.VIDEO | filters.Document.VIDEO, owner_only(self.on_video)))
        add(MessageHandler(filters.Document.FileExtension("json"), owner_only(self.on_json)))
        add(MessageHandler(filters.PHOTO | filters.Document.IMAGE, owner_only(self.on_image)))
        add(MessageHandler(filters.TEXT & ~filters.COMMAND, owner_only(self.on_text)))
        add(CallbackQueryHandler(owner_only(self.on_callback)))

    async def start(self):
        await self.app.initialize()
        await self.app.start()
        await self.app.updater.start_polling(drop_pending_updates=False)
        try:
            await self.app.bot.set_my_commands([
                BotCommand("queue", "What's scheduled and what went out"),
                BotCommand("autopilot", "Hands-free posting on/off, slots, defaults"),
                BotCommand("channels", "Connected accounts"),
                BotCommand("assets", "Logos and endings"),
                BotCommand("dashboard", "Web dashboard link + password"),
                BotCommand("cancel", "Stop whatever I was asking you for"),
            ])
        except TelegramError:
            pass
        log.info("Telegram bot started")

    async def stop(self):
        try:
            await self.app.updater.stop()
            await self.app.stop()
            await self.app.shutdown()
        except Exception:
            pass

    async def notify(self, text: str):
        if config.OWNER_ID:
            await self.app.bot.send_message(config.OWNER_ID, text)

    # ── job card ──────────────────────────────────────────────────────────
    def card_text(self, job: dict) -> str:
        st = job["status"]
        head = f"{STATUS_ICON.get(st, '')} <b>Video #{job['id']}</b>"
        lines = []
        if st == "draft":
            lines.append(f"{head} — ready when you are")
        elif st == "scheduled":
            lines.append(f"{head} — {esc(job['message'] or 'queued')}")
        elif st in ("processing", "posting"):
            lines.append(f"{head} — {esc(job['message'])}")
            if st == "processing":
                lines.append(f"{bar(job['progress'])} {job['progress']}%")
        else:
            lines.append(f"{head} — {esc(job['message'] or st)}")

        if st in ("draft", "scheduled"):
            lines.append("")
            lines.append(f"Logo: <b>{esc(job['logo'] or 'none')}</b>   Ending: <b>{esc(job['ending'] or 'none')}</b>")
            cap = MODES[job["caption_mode"]]
            if job["caption_mode"] in ("ai", "template"):
                rule = job.get("rule")
                cap += f" — rule: <i>{esc(rule)}</i>" if rule else \
                       (" — I'll work the rule out from the video" if job["caption_mode"] == "ai" and captions.ai_available()
                        else " — no rule yet")
            elif job["caption_mode"] == "manual":
                text = job.get("captions", {}).get("all", "")
                cap += f" — <i>{esc(text[:80])}{'…' if len(text) > 80 else ''}</i>" if text else " — not written yet"
            lines.append(f"Caption: {cap}")
            if job["targets"]:
                lines.append("Post to: " + ", ".join(f"{cm.EMOJI[t['type']]} {esc(t['name'])}" for t in job["targets"]))
            else:
                lines.append("Post to: nowhere — I'll just send the edited video back")
        elif job["targets"]:
            lines.append("")
            for t in job["targets"]:
                line = f"{TARGET_ICON.get(t['status'], '▫️')} {cm.EMOJI[t['type']]} {esc(t['name'])}"
                if t["status"] == "ok" and t.get("url"):
                    line += f' — <a href="{esc(t["url"])}">open</a>'
                elif t["status"] == "failed":
                    line += f"\n     <i>{esc(t['error'][:160])}</i>"
                elif t["status"] == "posting" and t.get("attempts", 1) > 1:
                    line += f" (try {t['attempts']})"
                lines.append(line)
        if job.get("error"):
            lines.append(f"\n<i>{esc(job['error'][:300])}</i>")
        return "\n".join(lines)

    def card_keyboard(self, job: dict) -> Kb | None:
        j, st = job["id"], job["status"]
        if st == "draft":
            slot = self.p.next_slot()
            go = "🚀 Post now" if job["targets"] else "⚙️ Process now"
            rows = [[Btn(go, callback_data=f"j:{j}:now")]]
            if job["targets"] and self.store.get_settings()["slots"]:
                rows[0].append(Btn(f"🕒 {fmt_time(slot)}", callback_data=f"j:{j}:slot"))
            rows += [
                [Btn("🖼 Logo", callback_data=f"j:{j}:m:logo"), Btn("🎞 Ending", callback_data=f"j:{j}:m:ending")],
                [Btn("📝 Caption", callback_data=f"j:{j}:m:cap"), Btn("📡 Post to", callback_data=f"j:{j}:m:tg")],
                [Btn("💾 Save as my default", callback_data=f"j:{j}:save"), Btn("✖ Cancel", callback_data=f"j:{j}:cancel")],
            ]
            return Kb(rows)
        if st == "scheduled":
            return Kb([[Btn("🚀 Post now", callback_data=f"j:{j}:now"), Btn("✏️ Edit", callback_data=f"j:{j}:edit"),
                        Btn("✖ Cancel", callback_data=f"j:{j}:cancel")]])
        if st in ("partial", "failed"):
            return Kb([[Btn("🔁 Retry what failed", callback_data=f"j:{j}:retry")]])
        return None

    async def show_card(self, job: dict, message=None):
        """Edit the job's card in place; create it if it doesn't exist yet."""
        text, kb = self.card_text(job), self.card_keyboard(job)
        kwargs = dict(parse_mode=ParseMode.HTML, reply_markup=kb, disable_web_page_preview=True)
        if job.get("msg_id") and job.get("chat_id"):
            try:
                await self.app.bot.edit_message_text(text, job["chat_id"], job["msg_id"], **kwargs)
                return
            except BadRequest as e:
                if "not modified" in str(e).lower():
                    return
                log.debug("edit failed, sending a new card: %s", e)
        chat = job.get("chat_id") or config.OWNER_ID
        sent = await self.app.bot.send_message(chat, text, **kwargs)
        job.update(chat_id=chat, msg_id=sent.message_id)
        fresh = self.store.get_job(job["id"])
        if fresh:
            fresh.update(chat_id=chat, msg_id=sent.message_id)
            self.store.save_job(fresh)

    async def on_job_update(self, job: dict):
        final = job["status"] in ("done", "partial", "failed")
        if job["source"] != "telegram":
            if final and job["targets"]:           # dashboard jobs: one summary message, no live card
                await self.app.bot.send_message(config.OWNER_ID, self.card_text(job), parse_mode=ParseMode.HTML,
                                                reply_markup=self.card_keyboard(job), disable_web_page_preview=True)
            return
        await self.show_card(job)
        if job["status"] == "done" and not job["targets"] and not job.get("sent_back"):
            job["sent_back"] = True
            self.store.save_job(job)
            try:
                with open(job["output_path"], "rb") as f:
                    await self.app.bot.send_video(job["chat_id"], f, supports_streaming=True,
                                                  caption=f"Video #{job['id']} — edited",
                                                  read_timeout=300, write_timeout=300)
            except TelegramError as e:
                await self.app.bot.send_message(
                    job["chat_id"], f"Couldn't send #{job['id']} back here ({e}). "
                                    f"It's in the dashboard queue to download for the next 24 hours.")

    # ── commands ──────────────────────────────────────────────────────────
    async def cmd_start(self, update: Update, ctx):
        s, accounts = self.store.get_settings(), cm.flat_accounts()
        ready = sum(a["ready"] for a in accounts)
        auto = "ON — videos you send post themselves" if s["autopilot"] else "off"
        await update.message.reply_html(
            "🎬 <b>VideoBot</b>\n\n"
            f"Accounts connected: {ready} of {len(accounts)}\n"
            f"Autopilot: <b>{auto}</b>\n"
            f"Daily slots: {', '.join(s['slots']) or 'none'} ({config.TIMEZONE})\n"
            f"Next episode: {s['episode']}\n\n"
            "<b>Send me a video.</b> Add the episode's rule as the caption and I'll write the post text.\n"
            "Send a PNG <i>as a file</i> to save it as a logo or ending.\n\n"
            "/queue · /autopilot · /channels · /assets · /dashboard\n"
            "/addyt · /addig · /addfb · /slots · /episode")

    async def cmd_queue(self, update: Update, ctx):
        jobs = self.store.list_jobs(limit=15)
        active = [j for j in jobs if j["status"] in ACTIVE]
        recent = [j for j in jobs if j["status"] in ("done", "partial", "failed")][:6]
        lines = ["<b>Up next</b>"]
        for j in sorted(active, key=lambda x: x.get("run_at") or 0):
            to = ", ".join(t["name"] for t in j["targets"]) or "download"
            when = fmt_time(j["run_at"]) if j["status"] == "scheduled" else j["message"]
            lines.append(f"{STATUS_ICON[j['status']]} #{j['id']} — {esc(when)} → {esc(to)}")
        if not active:
            lines.append("Nothing queued. Send a video to fill a slot.")
        if recent:
            lines.append("\n<b>Recently</b>")
            for j in recent:
                lines.append(f"{STATUS_ICON[j['status']]} #{j['id']} — {esc(j['message'])}")
        rows = [[Btn(f"Open #{j['id']}", callback_data=f"j:{j['id']}:open")] for j in active[:6]]
        await update.message.reply_html("\n".join(lines), reply_markup=Kb(rows) if rows else None)

    def autopilot_panel(self) -> tuple[str, Kb]:
        s = self.store.get_settings()
        names = {a["key"]: a["name"] for a in cm.flat_accounts()}
        targets = ", ".join(names[k] for k in s["default_targets"] if k in names) or "none set"
        text = (f"🛫 <b>Autopilot is {'ON' if s['autopilot'] else 'off'}</b>\n\n"
                "When it's on, every video you send is queued for the next free slot and posted "
                "with your defaults. No buttons.\n\n"
                f"Slots: <b>{', '.join(s['slots']) or 'none — posts go out straight away'}</b> ({config.TIMEZONE})\n"
                f"Posts to: <b>{esc(targets)}</b>\n"
                f"Logo: <b>{esc(s['default_logo'] or 'none')}</b>   Ending: <b>{esc(s['default_ending'] or 'none')}</b>\n"
                f"Captions: <b>{MODES[s['caption_mode']]}</b>\n"
                f"Next episode: <b>{s['episode']}</b>\n\n"
                "Change the defaults from any video card with “Save as my default”.")
        if s["caption_mode"] == "ai" and not captions.ai_available():
            text += "\n\n⚠️ No GEMINI_API_KEY in .env, so AI captions fall back to the template."
        kb = Kb([[Btn("Turn off" if s["autopilot"] else "Turn on", callback_data="ap:toggle")],
                 [Btn("🕒 Change slots", callback_data="ap:slots"), Btn("📝 Caption style", callback_data="ap:mode")]])
        return text, kb

    async def cmd_autopilot(self, update: Update, ctx):
        text, kb = self.autopilot_panel()
        await update.message.reply_html(text, reply_markup=kb)

    async def cmd_slots(self, update: Update, ctx):
        if ctx.args:
            await self._set_slots(update, " ".join(ctx.args))
        else:
            ctx.user_data["awaiting"] = "slots"
            await update.message.reply_text("Send the daily posting times, e.g.  10:00 14:30 19:00\n(or “none” to post straight away)")

    async def _set_slots(self, update: Update, text: str):
        slots = []
        if text.strip().lower() != "none":
            for part in text.replace(",", " ").split():
                try:
                    h, m = part.split(":")
                    if not (0 <= int(h) < 24 and 0 <= int(m) < 60):
                        raise ValueError
                    slots.append(f"{int(h):02d}:{int(m):02d}")
                except ValueError:
                    await update.message.reply_text(f"“{part}” isn't a time. Use 24-hour HH:MM, e.g. 18:30.")
                    return
        self.store.update_settings(slots=sorted(set(slots)))
        await update.message.reply_text("Slots saved: " + (", ".join(sorted(set(slots))) or "none"))

    async def cmd_episode(self, update: Update, ctx):
        if ctx.args and ctx.args[0].isdigit():
            self.store.update_settings(episode=int(ctx.args[0]))
        await update.message.reply_text(f"Next episode: {self.store.get_settings()['episode']}\nChange it with /episode 12")

    async def cmd_channels(self, update: Update, ctx):
        lines = ["📡 <b>Accounts</b>"]
        for kind in ("yt", "ig", "fb"):
            accs = [a for a in cm.flat_accounts() if a["type"] == kind]
            lines.append(f"\n<b>{cm.LABEL[kind]}</b>")
            for a in accs:
                lines.append(f"{'✅' if a['ready'] else '⚠️ needs connecting —'} {esc(a['name'])} (<code>{esc(a['id'])}</code>)")
            if not accs:
                lines.append("<i>none</i>")
        lines.append("\nAdd: /addyt /addig /addfb")
        await update.message.reply_html("\n".join(lines))

    async def cmd_addig(self, update: Update, ctx):
        ctx.user_data.update(awaiting="ig_name", setup={})
        await update.message.reply_text("📸 New Instagram account.\nWhat should I call it? (e.g. Restory Central)")

    async def cmd_addfb(self, update: Update, ctx):
        ctx.user_data.update(awaiting="fb_name", setup={})
        await update.message.reply_text("🔵 New Facebook Page.\nWhat should I call it?")

    async def cmd_addyt(self, update: Update, ctx):
        ctx.user_data.update(awaiting="yt_name", setup={})
        await update.message.reply_text("▶️ New YouTube channel.\nWhat should I call it?")

    async def cmd_assets(self, update: Update, ctx):
        logos, endings = config.list_assets("logo"), config.list_assets("ending")
        await update.message.reply_html(
            "🗂 <b>Assets</b>\n\n<b>Logos</b>\n" + ("\n".join(f"• {esc(n)}" for n in logos) or "<i>none</i>") +
            "\n\n<b>Endings</b>\n" + ("\n".join(f"• {esc(n)}" for n in endings) or "<i>none</i>") +
            "\n\nSend a PNG as a file to add one. Remove with /deletelogo name.png or /deleteending name.png")

    async def _delete_asset(self, update: Update, ctx, kind: str):
        path = config.asset_path(kind, ctx.args[0]) if ctx.args else None
        if not path:
            await update.message.reply_text(f"Not found. Usage: /delete{kind} name.png")
            return
        os.remove(path)
        await update.message.reply_text(f"Deleted {os.path.basename(path)}")

    async def cmd_delete_logo(self, update, ctx):   await self._delete_asset(update, ctx, "logo")
    async def cmd_delete_ending(self, update, ctx): await self._delete_asset(update, ctx, "ending")

    async def cmd_dashboard(self, update: Update, ctx):
        if not config.DASH_ENABLED:
            await update.message.reply_text("The dashboard is switched off (DASH_ENABLED=0).")
            return
        host = config.VPS_PUBLIC_URL.split("//")[-1].split("/")[0].split(":")[0] or "your-server-ip"
        await update.message.reply_html(
            f"🖥 Dashboard: http://{esc(host)}:{config.DASH_PORT}\nPassword: <tg-spoiler>{esc(config.DASH_PASSWORD)}</tg-spoiler>")

    async def cmd_cancel(self, update: Update, ctx):
        ctx.user_data.pop("awaiting", None)
        await update.message.reply_text("Okay, dropped that.")

    # ── incoming media ────────────────────────────────────────────────────
    async def on_video(self, update: Update, ctx):
        msg = update.message
        video = msg.video or msg.document
        note = await msg.reply_text("⬇️ Getting your video…")
        name = config.safe_name(getattr(video, "file_name", None) or "video.mp4")
        dest = os.path.join(config.UPLOAD_DIR, f"tg_{int(time.time())}_{video.file_unique_id}_{name}")
        try:
            tg_file = await ctx.bot.get_file(video.file_id, read_timeout=120)
            await tg_file.download_to_drive(dest, read_timeout=600)
        except TelegramError as e:
            hint = ("Telegram only lets bots download files up to 20 MB. Upload this one through the "
                    "dashboard (/dashboard), or set TELEGRAM_API_URL to a local Bot API server."
                    if "too big" in str(e).lower() else str(e))
            await note.edit_text(f"❌ Couldn't download that video.\n{hint}")
            return

        s = self.store.get_settings()
        text = (msg.caption or "").strip()
        over = {"chat_id": msg.chat_id, "msg_id": note.message_id}
        if s["caption_mode"] == "manual":
            over["captions"] = {"all": text} if text else {}
        else:
            over["rule"] = text
        job = self.p.new_job(dest, "telegram", **over)

        if s["autopilot"] and job["targets"]:
            job = self.p.schedule(job, self.p.next_slot() if s["slots"] else None)
        await self.show_card(job)

    async def on_image(self, update: Update, ctx):
        msg = update.message
        if msg.photo:
            file_id, name = msg.photo[-1].file_id, f"image_{int(time.time())}.jpg"
            warn = "\n(Photos lose their transparent background. For a clean logo, send the PNG as a file.)"
        else:
            file_id, name, warn = msg.document.file_id, config.safe_name(msg.document.file_name or "image.png"), ""
        ctx.user_data["pending_asset"] = {"file_id": file_id, "name": name}
        await msg.reply_text(f"Save “{name}” as…{warn}", reply_markup=Kb([[
            Btn("🖼 Logo", callback_data="asset:logo"), Btn("🎞 Ending", callback_data="asset:ending")]]))

    async def on_json(self, update: Update, ctx):
        """client_secret.json for a YouTube channel."""
        if ctx.user_data.get("awaiting") != "yt_secret":
            await update.message.reply_text("If that's a YouTube client_secret.json, start with /addyt.")
            return
        name = ctx.user_data["setup"]["name"]
        ch_id = cm.make_id(name)
        rel = f"youtube/client_secret_{ch_id}.json"
        tg_file = await ctx.bot.get_file(update.message.document.file_id)
        await tg_file.download_to_drive(os.path.join(config.BASE_DIR, rel))
        os.chmod(os.path.join(config.BASE_DIR, rel), 0o600)
        cm.add_yt_channel(ch_id, name, rel)
        await self._yt_auth_prompt(update, ctx, ch_id)

    async def _yt_auth_prompt(self, update: Update, ctx, ch_id: str):
        from youtube.uploader import YouTubeUploader
        try:
            url = YouTubeUploader(cm.get_account("yt", ch_id)).auth_url()
        except Exception as e:
            ctx.user_data.pop("awaiting", None)
            await update.message.reply_text(f"❌ {e}")
            return
        ctx.user_data.update(awaiting="yt_code", setup={"id": ch_id})
        await update.message.reply_html(
            "Almost there. Authorise the channel:\n\n"
            f'1. <a href="{esc(url)}">Open this Google link</a> and allow access with the channel\'s account.\n'
            "2. Your browser will then show a “can't reach localhost” page. That's expected.\n"
            "3. Copy the whole address from the address bar and paste it here.",
            disable_web_page_preview=True)

    # ── text replies (answers to something I asked) ───────────────────────
    async def on_text(self, update: Update, ctx):
        awaiting = ctx.user_data.get("awaiting")
        text = update.message.text.strip()
        setup = ctx.user_data.setdefault("setup", {})
        if not awaiting:
            await update.message.reply_text("Send me a video to post, or /start to see what I can do.")
            return

        async def forget_message():                 # tokens shouldn't sit in chat history
            try:
                await update.message.delete()
            except TelegramError:
                pass

        if awaiting == "slots":
            ctx.user_data.pop("awaiting")
            await self._set_slots(update, text)

        elif awaiting.startswith("rule:") or awaiting.startswith("own:"):
            kind, job_id = awaiting.split(":")
            ctx.user_data.pop("awaiting")
            job = self.store.get_job(int(job_id))
            if not job or job["status"] not in ("draft", "scheduled"):
                await update.message.reply_text("That video has already gone out.")
                return
            if kind == "rule":
                job["rule"] = text
            else:
                job.update(caption_mode="manual", captions={"all": text})
            for t in job["targets"]:
                t.pop("caption", None)
            job["msg_id"] = None                    # put a fresh card below the reply
            self.store.save_job(job)
            await self.show_card(job)

        elif awaiting == "ig_name":
            setup["name"] = text
            ctx.user_data["awaiting"] = "ig_token"
            await update.message.reply_text("Paste the long-lived Instagram access token.\n(I'll delete your message once I've saved it.)")
        elif awaiting == "ig_token":
            setup["token"] = text
            await forget_message()
            ctx.user_data["awaiting"] = "ig_user"
            await update.message.chat.send_message("Got it. Now the Instagram user ID (the number).")
        elif awaiting == "ig_user":
            ctx.user_data.pop("awaiting")
            result = cm.add_ig_account(cm.make_id(setup["name"]), setup["name"], setup["token"], text)
            await update.message.reply_text(f"✅ Instagram account “{setup['name']}” {result}. I'll renew its token automatically.")

        elif awaiting == "fb_name":
            setup["name"] = text
            ctx.user_data["awaiting"] = "fb_page"
            await update.message.reply_text("What's the Facebook Page ID?")
        elif awaiting == "fb_page":
            setup["page"] = text
            ctx.user_data["awaiting"] = "fb_token"
            await update.message.reply_text("Paste the Page access token.\n(I'll delete your message once I've saved it.)")
        elif awaiting == "fb_token":
            ctx.user_data.pop("awaiting")
            await forget_message()
            result = cm.add_fb_account(cm.make_id(setup["name"]), setup["name"], setup["page"], text)
            await update.message.chat.send_message(f"✅ Facebook Page “{setup['name']}” {result}.")

        elif awaiting == "yt_name":
            setup["name"] = text
            ctx.user_data["awaiting"] = "yt_secret"
            await update.message.reply_text(
                "Now send the client_secret.json file.\n"
                "Google Cloud Console → APIs & Services → Credentials → create an OAuth client of type "
                "“Desktop app” → Download JSON.")
        elif awaiting == "yt_secret":
            await update.message.reply_text("I need the client_secret.json as a file. /cancel to stop.")
        elif awaiting == "yt_code":
            from youtube.uploader import YouTubeUploader
            ch = cm.get_account("yt", setup.get("id", ""))
            try:
                YouTubeUploader(ch).finish_auth(text)
            except Exception as e:
                await update.message.reply_text(f"❌ That didn't work: {e}\nPaste the address again, or /cancel.")
                return
            ctx.user_data.pop("awaiting")
            await update.message.reply_text(f"✅ YouTube channel “{ch['name']}” is connected and ready.")

    # ── buttons ───────────────────────────────────────────────────────────
    async def on_callback(self, update: Update, ctx):
        q = update.callback_query
        data = q.data or ""
        try:
            if data.startswith("j:"):
                await self._job_button(q, ctx, data.split(":"))
            elif data.startswith("ap:"):
                await self._autopilot_button(q, ctx, data[3:])
            elif data.startswith("asset:"):
                await self._save_asset(q, ctx, data[6:])
            else:
                await q.answer()
        except BadRequest as e:
            if "not modified" not in str(e).lower():
                raise
            await q.answer()

    async def _save_asset(self, q, ctx, kind: str):
        pending = ctx.user_data.pop("pending_asset", None)
        if not pending:
            await q.answer("Send the image again.")
            return
        directory = config.LOGOS_DIR if kind == "logo" else config.ENDINGS_DIR
        tg_file = await ctx.bot.get_file(pending["file_id"])
        await tg_file.download_to_drive(os.path.join(directory, pending["name"]))
        await q.answer("Saved")
        await q.edit_message_text(f"✅ Saved {kind} “{pending['name']}”. Pick it from the Logo/Ending menu on any video.")

    async def _autopilot_button(self, q, ctx, action: str):
        s = self.store.get_settings()
        if action == "toggle":
            if not s["autopilot"] and not s["default_targets"]:
                await q.answer("Set where to post first: send a video, choose accounts, tap “Save as my default”.",
                               show_alert=True)
                return
            self.store.update_settings(autopilot=not s["autopilot"])
        elif action == "mode":
            order = list(MODES)
            self.store.update_settings(caption_mode=order[(order.index(s["caption_mode"]) + 1) % len(order)])
        elif action == "slots":
            ctx.user_data["awaiting"] = "slots"
            await q.answer()
            await q.message.reply_text("Send the daily posting times, e.g.  10:00 14:30 19:00\n(or “none”)")
            return
        await q.answer()
        text, kb = self.autopilot_panel()
        await q.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

    async def _job_button(self, q, ctx, parts: list[str]):
        job = self.store.get_job(int(parts[1]))
        action = parts[2]
        if not job:
            await q.answer("That video is no longer in the queue.", show_alert=True)
            return
        job.update(chat_id=q.message.chat_id, msg_id=q.message.message_id)
        editable = job["status"] in ("draft", "scheduled")

        if action == "open":
            job["msg_id"] = None
            await q.answer()
            await self.show_card(job)
            return
        if action == "retry":
            await q.answer("Retrying")
            self.store.save_job(job)
            self.p.retry_failed(job["id"])
            return
        if action == "cancel":
            await q.answer("Cancelled")
            self.store.save_job(job)
            await self.show_card(self.p.cancel(job["id"]))
            return
        if not editable:
            await q.answer("This one is already on its way.")
            return

        if action == "now":
            if job["caption_mode"] == "manual" and job["targets"] and not job.get("captions", {}).get("all"):
                await q.answer("Write the caption first (Caption → My own text).", show_alert=True)
                return
            await q.answer("On it")
            self.p.schedule(job, None)
        elif action == "slot":
            await q.answer()
            self.p.schedule(job, self.p.next_slot())
        elif action == "edit":
            job.update(status="draft", run_at=None, message="")
            self.store.save_job(job)
            await q.answer()
            await self.show_card(job)
        elif action == "save":
            self.store.update_settings(default_logo=job["logo"], default_ending=job["ending"],
                                       caption_mode=job["caption_mode"],
                                       default_targets=[f"{t['type']}:{t['id']}" for t in job["targets"]])
            await q.answer("Saved. New videos start with this setup.", show_alert=True)
        elif action == "back":
            self.store.save_job(job)
            await q.answer()
            await self.show_card(job)
        elif action == "m":
            await q.answer()
            await self._submenu(q, job, parts[3])
        elif action in ("logo", "ending"):
            names = config.list_assets(action)
            idx = int(parts[3])
            job[action] = names[idx] if 0 <= idx < len(names) else ""
            self.store.save_job(job)
            await q.answer()
            await self.show_card(job)
        elif action == "cap":
            choice = parts[3]
            await q.answer()
            if choice == "rule":
                ctx.user_data["awaiting"] = f"rule:{job['id']}"
                await q.message.reply_text("What's the rule this episode?\ne.g. everyone turns invisible at midnight except me")
                return
            if choice == "manual":
                ctx.user_data["awaiting"] = f"own:{job['id']}"
                await q.message.reply_text("Send the caption exactly as it should be posted.")
                return
            job["caption_mode"] = choice
            for t in job["targets"]:
                t.pop("caption", None)
            self.store.save_job(job)
            await self.show_card(job)
        elif action == "tg":
            accounts = cm.flat_accounts()
            idx = int(parts[3])
            if 0 <= idx < len(accounts):
                key = accounts[idx]["key"]
                keys = [f"{t['type']}:{t['id']}" for t in job["targets"]]
                keys = [k for k in keys if k != key] if key in keys else keys + [key]
                job["targets"] = self.p.expand_targets(keys)
                self.store.save_job(job)
            await q.answer()
            await self._submenu(q, job, "tg")

    async def _submenu(self, q, job: dict, which: str):
        j = job["id"]
        back = [Btn("← Back", callback_data=f"j:{j}:back")]
        if which in ("logo", "ending"):
            names = config.list_assets(which)
            rows = [[Btn(("● " if n == job[which] else "") + n, callback_data=f"j:{j}:{which}:{i}")]
                    for i, n in enumerate(names)]
            rows.append([Btn(("● " if not job[which] else "") + "None", callback_data=f"j:{j}:{which}:-1")])
            title = f"Choose the {which}." + ("" if names else " None saved yet — send me a PNG as a file to add one.")
        elif which == "cap":
            rows = [[Btn(("● " if job["caption_mode"] == m else "") + label, callback_data=f"j:{j}:cap:{m}")]
                    for m, label in MODES.items()]
            rows.insert(2, [Btn("✏️ Set this episode's rule", callback_data=f"j:{j}:cap:rule")])
            title = ("How should the caption be written?\n"
                     "AI and Template build it from the episode's rule; each account gets its own wording.")
        else:
            current = {f"{t['type']}:{t['id']}" for t in job["targets"]}
            rows = [[Btn(f"{'✅' if a['key'] in current else '◻️'} {cm.EMOJI[a['type']]} {a['name']}"
                         f"{'' if a['ready'] else '  (not connected)'}", callback_data=f"j:{j}:tg:{i}")]
                    for i, a in enumerate(cm.flat_accounts())]
            title = "Tap accounts to switch them on or off. With none selected I just send the edited video back."
        rows.append(back)
        await q.edit_message_text(title, reply_markup=Kb(rows))
