"""Facebook Reels via the Graph API (Page ID + Page access token)."""
import logging
import os

import aiohttp

log = logging.getLogger(__name__)
GRAPH = "https://graph.facebook.com/v21.0"


def _err(d) -> str:
    e = d.get("error", {}) if isinstance(d, dict) else {}
    return e.get("error_user_msg") or e.get("message") or str(d)[:300]


class FacebookPoster:
    def __init__(self, account: dict):
        self.account = account
        self.page_id = account["page_id"]
        self.token   = account["access_token"]

    async def post(self, video_path: str, caption: str) -> dict:
        timeout = aiohttp.ClientTimeout(total=900)
        async with aiohttp.ClientSession(timeout=timeout) as s:
            async with s.post(f"{GRAPH}/{self.page_id}/video_reels",
                              params={"access_token": self.token},
                              json={"upload_phase": "start"}) as r:
                d = await r.json(content_type=None)
            if "video_id" not in d:
                raise RuntimeError(f"Facebook refused the upload: {_err(d)}")
            video_id, upload_url = d["video_id"], d["upload_url"]

            size = os.path.getsize(video_path)
            with open(video_path, "rb") as f:
                async with s.post(upload_url, data=f, headers={
                        "Authorization": f"OAuth {self.token}", "offset": "0",
                        "file_size": str(size), "Content-Length": str(size)}) as r:
                    d = await r.json(content_type=None)
                    if r.status >= 400 or not d.get("success", True):
                        raise RuntimeError(f"Facebook upload failed: {_err(d)}")

            async with s.post(f"{GRAPH}/{self.page_id}/video_reels",
                              params={"access_token": self.token},
                              json={"upload_phase": "finish", "video_id": video_id,
                                    "video_state": "PUBLISHED", "description": caption}) as r:
                d = await r.json(content_type=None)
            if r.status >= 400 or "error" in d:
                raise RuntimeError(f"Facebook publish failed: {_err(d)}")
        log.info("[%s] Facebook reel %s", self.account["name"], video_id)
        return {"id": video_id, "url": f"https://www.facebook.com/reel/{video_id}"}
