"""SQLite persistence: jobs survive restarts, settings live in a key/value table."""
import json
import sqlite3
import threading
import time

import config

DEFAULT_SETTINGS = {
    "autopilot": False,            # videos sent to the bot are queued + posted with zero taps
    "slots": ["10:00", "18:30"],   # daily posting times (TIMEZONE)
    "default_targets": [],         # ["yt:yt1", "ig:ig1"]
    "default_logo": "",
    "default_ending": "",
    "caption_mode": "ai",          # ai | template | manual | none
    "episode": 1,                  # next episode number, bumps itself
}

ACTIVE = ("scheduled", "processing", "posting")


class Store:
    def __init__(self, path: str = config.DB_PATH):
        self._db = sqlite3.connect(path, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        self._lock = threading.RLock()
        with self._lock, self._db:
            self._db.execute("PRAGMA journal_mode=WAL")
            self._db.execute("""CREATE TABLE IF NOT EXISTS jobs(
                id INTEGER PRIMARY KEY AUTOINCREMENT, status TEXT NOT NULL,
                run_at REAL, created_at REAL NOT NULL, data TEXT NOT NULL)""")
            self._db.execute("CREATE INDEX IF NOT EXISTS jobs_status ON jobs(status, run_at)")
            self._db.execute("CREATE TABLE IF NOT EXISTS kv(key TEXT PRIMARY KEY, value TEXT NOT NULL)")

    # ── jobs ──────────────────────────────────────────────────────────────
    @staticmethod
    def _row(row) -> dict:
        job = json.loads(row["data"])
        job.update(id=row["id"], status=row["status"], run_at=row["run_at"], created_at=row["created_at"])
        return job

    def create_job(self, **data) -> dict:
        job = {
            "source": "web", "input_path": "", "output_path": "",
            "logo": "", "ending": "", "rule": "", "episode": 1,
            "caption_mode": "ai", "captions": {}, "targets": [],
            "progress": 0, "message": "", "error": "",
            "chat_id": None, "msg_id": None, "finished_at": None,
        }
        job.update(data)
        status = job.pop("status", "draft")
        run_at = job.pop("run_at", None)
        now = time.time()
        with self._lock, self._db:
            cur = self._db.execute(
                "INSERT INTO jobs(status, run_at, created_at, data) VALUES(?,?,?,?)",
                (status, run_at, now, json.dumps(job)))
        job.update(id=cur.lastrowid, status=status, run_at=run_at, created_at=now)
        return job

    def save_job(self, job: dict) -> None:
        data = {k: v for k, v in job.items() if k not in ("id", "status", "run_at", "created_at")}
        with self._lock, self._db:
            self._db.execute("UPDATE jobs SET status=?, run_at=?, data=? WHERE id=?",
                             (job["status"], job.get("run_at"), json.dumps(data), job["id"]))

    def get_job(self, job_id: int) -> dict | None:
        with self._lock:
            row = self._db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        return self._row(row) if row else None

    def list_jobs(self, statuses: tuple | None = None, limit: int = 60) -> list[dict]:
        sql, args = "SELECT * FROM jobs", []
        if statuses:
            sql += f" WHERE status IN ({','.join('?' * len(statuses))})"
            args += list(statuses)
        sql += " ORDER BY id DESC LIMIT ?"
        with self._lock:
            rows = self._db.execute(sql, (*args, limit)).fetchall()
        return [self._row(r) for r in rows]

    def due_jobs(self, now: float) -> list[dict]:
        with self._lock:
            rows = self._db.execute(
                "SELECT * FROM jobs WHERE status='scheduled' AND (run_at IS NULL OR run_at<=?) "
                "ORDER BY COALESCE(run_at,0), id", (now,)).fetchall()
        return [self._row(r) for r in rows]

    def delete_job(self, job_id: int) -> None:
        with self._lock, self._db:
            self._db.execute("DELETE FROM jobs WHERE id=?", (job_id,))

    # ── settings ──────────────────────────────────────────────────────────
    def get_settings(self) -> dict:
        with self._lock:
            row = self._db.execute("SELECT value FROM kv WHERE key='settings'").fetchone()
        out = dict(DEFAULT_SETTINGS)
        if row:
            out.update(json.loads(row["value"]))
        return out

    def update_settings(self, **patch) -> dict:
        with self._lock:
            cur = self.get_settings()
            cur.update({k: v for k, v in patch.items() if k in DEFAULT_SETTINGS})
            with self._db:
                self._db.execute("INSERT INTO kv(key,value) VALUES('settings',?) "
                                 "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (json.dumps(cur),))
        return cur

    def take_episode(self) -> int:
        """Return the next episode number and advance the counter."""
        with self._lock:
            ep = int(self.get_settings()["episode"])
            self.update_settings(episode=ep + 1)
        return ep
