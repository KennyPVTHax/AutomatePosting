"""No network or API credentials needed: python -m unittest test_v7_processing.py"""
import unittest
from processing.processor import build_command

class ProcessingOptionsTests(unittest.TestCase):
    def setUp(self):
        self.meta = {"duration": 60, "width": 1080, "height": 1920, "has_audio": True}

    def test_unchanged_video_does_not_reencode(self):
        cmd = build_command("input.mp4", "output.mp4", self.meta, None, None, 1.0, 1.0)
        self.assertIn("copy", cmd)

    def test_enhancement_uses_ffmpeg_filter(self):
        cmd = build_command("input.mp4", "output.mp4", self.meta, None, None, 1.1, 1.02)
        self.assertIn("eq=contrast=1.020", cmd[cmd.index("-filter_complex") + 1])

    def test_logo_placement(self):
        for pos, expected in (("top-left", "x=20"), ("bottom-right", "x=W-w-20")):
            cmd = build_command("input.mp4", "output.mp4", self.meta, "logo.png", None, 1.02, 1.01, pos)
            self.assertIn(expected, cmd[cmd.index("-filter_complex") + 1])

    def test_optional_ending_is_skipped(self):
        cmd = build_command("input.mp4", "output.mp4", self.meta, None, None, 1.02, 1.01)
        self.assertEqual(cmd.count("-i"), 1)

if __name__ == "__main__":
    unittest.main()
