# VideoBot v7 safe staging guide

This is a **v7 staging baseline**, NOT complete OAuth automation. It preserves the v6 dashboard, scheduling and upload code.

## What is changed
- Dashboard defaults to `127.0.0.1:8090` (not public `0.0.0.0:8080`).
- Dashboard passwords are never logged by the runner.
- Dashboard session cookies are marked `Secure`; login needs an HTTPS browser origin.
- `install_v7_service.sh` creates `videobot-v7.service`, without replacing the disabled v2 service or editing Nginx.

## Precautions
- **DO NOT run the original `setup.sh` on this VPS**. It rewrites the existing `videobot` systemd unit and Nginx default site.
- **DO NOT point a public HTTP URL at port 8090**; it is for loopback only. The secure cookie requires HTTPS.
- Existing NEMESIS/SpreadBot must remain intact. Do not change their services or Nginx blocks.
- The older dashboard auth scheme still needs a comprehensive CSRF/session-hardening pass before public deployment. Do not expose this starter publicly yet.
- Video sizes are not unlimited: check reverse-proxy request limits, media storage, disk quota and platform media specifications.
- Preserve owner credentials in `.env` (chmod 600). Do not send secrets in chat.

## Suggested staging sequence (after choosing a hostname)
1. Move this folder into a **new** dedicated path, e.g. `/opt/videobot-v7` (not `/root/videobot`).
2. Copy `.env.example` to `.env`. Use `DASH_HOST=127.0.0.1`, `DASH_PORT=8090`, and an HTTPS public URL when ready.
3. Create a new service using `./install_v7_service.sh` after reviewing its contents. Installer does not start it.
4. Add a dedicated Nginx hostname with SSL terminating at Nginx and proxying to `127.0.0.1:8090`; never overwrite `nemesis.conf`.
5. After completing dashboard security review, start the new service; test login, video upload, schedule, platform authorization and recovery.

## Not yet implemented
- Meta one-click login, Facebook Page discovery, Google one-click web OAuth.
- Resumable/chunked uploads and a durable de-duplication ledger.
- Full CSRF and abuse protections; production-ready reverse-proxy template.
