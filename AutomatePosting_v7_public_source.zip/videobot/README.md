# VideoBot v6

Telegram bot + web dashboard + scheduler in **one process** (`python run.py`), sharing one queue.

## Install (fresh VPS)

```bash
unzip videobot_v6.zip && cd videobot
./setup.sh                 # FFmpeg, nginx, venv, systemd service
nano .env                  # BOT_TOKEN, OWNER_ID, VPS_PUBLIC_URL, GEMINI_API_KEY
sudo systemctl restart videobot
```

## Upgrade from v5

1. Copy over your old `channels.json`, `assets/`, `youtube/client_secret*.json` and `youtube/tokens/`.
2. Copy your old `.env`, then add `GEMINI_API_KEY=` (and optionally `DASH_PASSWORD=`).
3. `./setup.sh` again (it rewrites the service to start `run.py` instead of `bot.py`).

The old Gemini key was hard-coded in `dashboard/app.py`. Treat it as leaked: revoke it in
Google AI Studio and put a new one in `.env`.

## Daily use

**Telegram:** send a video. Put the episode's rule in the caption. One card appears with your saved
setup; tap **Post now** or the next slot. Send a PNG *as a file* to add a logo or ending.

**Autopilot** (`/autopilot`): turn it on and every video you send is queued for the next free daily
slot, captioned and posted with no taps. You get the links when it goes out. Set where it posts by
choosing accounts on any video card and tapping **Save as my default**.

**Dashboard:** `/dashboard` in the bot gives the link and password. Post, watch the queue, edit
slots, manage accounts and assets from your phone.

| Command | What it does |
|---|---|
| `/queue` | What's scheduled, what went out |
| `/autopilot` | Hands-free mode, slots, caption style |
| `/slots 10:00 18:30` | Daily posting times |
| `/episode 12` | Set the next episode number |
| `/channels` `/addyt` `/addig` `/addfb` | Accounts |
| `/assets` `/deletelogo` `/deleteending` | Logos and endings |
| `/dashboard` | Web link + password |

## Connecting YouTube

Google retired the old "copy this code" flow v5 used. Now: create an OAuth client of type
**Desktop app**, upload its JSON (bot `/addyt` or dashboard → Library), open the Google link, allow
access, then copy the address of the "can't reach localhost" page your browser lands on and paste
it back.

## Files

```
run.py                  starts everything
bot.py                  Telegram UI
dashboard/              web UI (FastAPI + one HTML file)
pipeline.py             queue, scheduler, retries, token renewal
processing/processor.py FFmpeg
captions.py             template + Gemini captions
youtube/ instagram/ facebook/   uploaders
data/                   database, uploads, processed videos (kept 24 h)
```
