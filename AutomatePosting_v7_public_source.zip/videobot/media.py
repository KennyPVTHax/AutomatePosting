"""Public file hosting for Instagram, which pulls the video from a URL."""
import os
import secrets
import shutil
import time

import config


def publish(video_path: str) -> tuple[str, str]:
    """Expose a file at an unguessable public URL. Returns (url, local_copy_path)."""
    if not config.VPS_PUBLIC_URL:
        raise RuntimeError("VPS_PUBLIC_URL is not set in .env — Instagram needs a public link to fetch the video.")
    name = f"{secrets.token_urlsafe(12)}.mp4"
    dest = os.path.join(config.SERVE_DIR, name)
    try:
        os.link(video_path, dest)                  # instant, no extra disk
    except OSError:
        shutil.copyfile(video_path, dest)
    os.chmod(dest, 0o644)
    return f"{config.VPS_PUBLIC_URL}/videos/{name}", dest


def unpublish(path: str) -> None:
    try:
        os.remove(path)
    except OSError:
        pass


def sweep(max_age: float = 3600) -> None:
    now = time.time()
    for f in os.listdir(config.SERVE_DIR):
        p = os.path.join(config.SERVE_DIR, f)
        if f.endswith(".mp4") and os.path.isfile(p) and now - os.path.getmtime(p) > max_age:
            unpublish(p)
