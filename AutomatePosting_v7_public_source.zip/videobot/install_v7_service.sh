#!/usr/bin/env bash
# Safe installer for a separate v7 systemd unit. Does NOT change nginx or existing services.
set -euo pipefail
cd "$(dirname "$0")"
DIR="$(pwd -P)"
if [[ "$DIR" == /root/videobot ]]; then
  echo 'ERROR: Refusing to install over the existing v2 directory.' >&2; exit 1
fi
if [[ ! -f .env ]]; then
  cp .env.example .env
  chmod 600 .env
  echo 'Created .env; configure it BEFORE starting the service.'
fi
if [[ ! -d .venv ]]; then python3 -m venv .venv; fi
.venv/bin/pip install -r requirements.txt
# Existing services are neither stopped nor overwritten.
sudo tee /etc/systemd/system/videobot-v7.service >/dev/null <<UNIT
[Unit]
Description=VideoBot v7 (web dashboard and scheduler)
After=network-online.target
Wants=network-online.target
[Service]
Type=simple
WorkingDirectory=$DIR
ExecStart=$DIR/.venv/bin/python run.py
User=$(id -un)
Restart=on-failure
RestartSec=5
UMask=0077
NoNewPrivileges=true
[Install]
WantedBy=multi-user.target
UNIT
sudo systemctl daemon-reload
printf '\nInstalled v7 unit (NOT started). Check .env and HTTPS proxy first.\n'
printf 'Then: sudo systemctl enable --now videobot-v7.service\n'
