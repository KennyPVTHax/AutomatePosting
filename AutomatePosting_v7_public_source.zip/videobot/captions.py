"""
Captions for the "In This Town" series.

Two engines:
  • template — instant, offline, randomised hooks/CTAs/hashtags
  • ai       — Gemini writes every platform + every per-account variation in ONE request.
               If no rule was given it looks at stills from the video and works the rule out itself.
AI failures always fall back to the template, so a post is never blocked on a caption.
"""
import base64
import json
import logging
import random

import aiohttp

import config

log = logging.getLogger(__name__)

PLATFORMS = {"yt": "youtube", "ig": "instagram", "fb": "facebook"}

HOOKS = [
    "In This Town, {rule} 😱",
    "In This Town, {rule}... 😨",
    "In This Town, {rule} 💀",
    "In This Town, {rule} 😳",
    "In This Town, {rule} 🧟",
    "In This Town, {rule}... and I was the only one who survived 😭",
    "POV: You just discovered the rule — {rule} 👀",
    "Nobody told me about the rule until it was too late... {rule} 😰",
]
NO_RULE_HOOKS = [
    "In This Town, nothing is what it seems 😱",
    "In This Town, there's a rule nobody warned me about 💀",
    "POV: You moved to the wrong town 👀",
]
BODY = [
    "Nobody told me about the rule until it was too late...",
    "Everyone knew the rule. I didn't. That was my biggest mistake.",
    "I thought it was just a story. I was wrong.",
    "The rule changed everything. Watch till the end. 👇",
    "Part {ep} — will I survive this time? 😰",
    "They all warned me. I didn't listen.",
    "One rule. One town. One chance to escape. 💔",
    "I should have left when I had the chance...",
    "Everyone followed the rule. Except me. 😳",
]
CTAS = [
    "Follow for Part {next_ep} 👇",
    "Drop a 👁️ if you want Part {next_ep}!",
    "Comment 'MORE' for the next episode 🔥",
    "Like + Follow for Part {next_ep} — dropping tomorrow 👇",
    "Part {next_ep} is INSANE. Follow so you don't miss it 😱",
    "Subscribe for Part {next_ep} 🔔",
]
HASHTAGS = {
    "youtube":   "#roblox #Shorts #inthistown #robloxstory #robloxdrama #robloxhorror #robloxgaming #robloxfyp #gaming #subscribe",
    "instagram": "#roblox #robloxstory #inthistown #robloxdrama #robloxshorts #robloxfyp #gaming #storytime #viral #fyp #reels",
    "facebook":  "#roblox #robloxstory #inthistown #robloxdrama #gaming #viral #robloxfyp",
}
PLATFORM_SUFFIX = {
    "youtube":   "🔔 Subscribe and turn on notifications so you never miss an episode!",
    "instagram": "💬 DM me 'MORE' for the next part! Follow @restorycentral 🔥",
    "facebook":  "👍 Like this page for more Roblox stories! Share with a friend who loves drama 😱",
}
PLATFORM_STYLE = {
    "youtube":   "YouTube Shorts — suspenseful, 1-2 emojis per line, Subscribe CTA, 10 hashtags incl. #Shorts #roblox. First line doubles as the video title (max 90 characters).",
    "instagram": "Instagram Reels — heavy emojis, viral Gen-Z tone, Follow CTA, 15 hashtags incl. #fyp #reels",
    "facebook":  "Facebook Reels — storytelling tone, Like-the-Page CTA, 7 hashtags",
}


def ai_available() -> bool:
    return bool(config.GEMINI_API_KEY)


# ── template engine ──────────────────────────────────────────────────────────
def template_caption(rule: str, platform: str, episode: int) -> str:
    platform = PLATFORMS.get(platform, platform)
    rule = rule.strip().rstrip(".!?")
    if rule:
        hook = random.choice(HOOKS).format(rule=rule[0].upper() + rule[1:])
    else:
        hook = random.choice(NO_RULE_HOOKS)
    tags = HASHTAGS.get(platform, HASHTAGS["instagram"]).split()
    rest = tags[2:]
    random.shuffle(rest)
    parts = [hook, "", random.choice(BODY).format(ep=episode), "",
             random.choice(CTAS).format(next_ep=episode + 1)]
    if PLATFORM_SUFFIX.get(platform):
        parts += ["", PLATFORM_SUFFIX[platform]]
    parts += ["", " ".join(tags[:2] + rest)]
    return "\n".join(parts)


# kept for anything importing the old name
def generate_caption(format_type: str, rule: str = "", platform: str = "instagram", episode: int = 1) -> str:
    return template_caption(rule, platform, episode) if format_type == "inthistown" else rule


# ── AI engine ────────────────────────────────────────────────────────────────
async def _gemini(parts: list[dict]) -> dict:
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{config.GEMINI_MODEL}:generateContent"
    body = {"contents": [{"parts": parts}],
            "generationConfig": {"responseMimeType": "application/json"}}
    timeout = aiohttp.ClientTimeout(total=45)
    async with aiohttp.ClientSession(timeout=timeout) as s:
        async with s.post(url, json=body, headers={"x-goog-api-key": config.GEMINI_API_KEY}) as r:
            data = await r.json(content_type=None)
            if r.status != 200:
                raise RuntimeError(f"Gemini {r.status}: {str(data.get('error', {}).get('message', data))[:200]}")
    text = "".join(p.get("text", "") for p in data["candidates"][0]["content"]["parts"])
    return json.loads(text)


async def ai_captions(rule: str, episode: int, counts: dict[str, int],
                      frames: list[bytes] | None = None) -> tuple[dict[str, list[str]], str]:
    """counts: {"yt": 2, "ig": 1} → ({"yt": [cap, cap], "ig": [cap]}, rule_used)"""
    wanted = {PLATFORMS[k]: n for k, n in counts.items() if n > 0}
    spec = "\n".join(f'- "{p}": {n} caption(s). Style: {PLATFORM_STYLE[p]}' for p, n in wanted.items())
    rule_line = (f"Rule this episode: {rule}" if rule else
                 "No rule was given. Look at the attached stills from the video and infer this "
                 "episode's rule as one short sentence fragment (e.g. \"everyone turns invisible at midnight\").")
    prompt = f"""You write captions for a viral Roblox horror/drama short-form series called "In This Town".
Every episode shows one strange rule the town lives by.

{rule_line}
Episode number: {episode}

Write captions for:
{spec}

Each caption: punchy hook about the rule first, 2-3 short paragraphs of fear/shock/suspense,
the platform's CTA teasing Part {episode + 1}, hashtags on the last line, under 150 words.
When a platform needs more than one caption, each must open with a completely different hook
(they go to different accounts and must not look duplicated).

Return JSON only: {{"rule": "<the rule>", {", ".join(f'"{p}": ["..."]' for p in wanted)}}}"""
    parts: list[dict] = [{"text": prompt}]
    if not rule:
        for jpg in frames or []:
            parts.append({"inline_data": {"mime_type": "image/jpeg", "data": base64.b64encode(jpg).decode()}})
    data = await _gemini(parts)
    out = {}
    for short, n in counts.items():
        got = data.get(PLATFORMS[short]) or []
        if isinstance(got, str):
            got = [got]
        got = [c.strip() for c in got if isinstance(c, str) and c.strip()]
        if len(got) < n:
            raise RuntimeError("AI returned too few captions")
        out[short] = got[:n]
    return out, (rule or str(data.get("rule", "")).strip())


async def build_captions(mode: str, rule: str, episode: int, counts: dict[str, int],
                         manual: dict[str, str] | None = None,
                         frames_fn=None) -> tuple[dict[str, list[str]], str, str]:
    """
    Returns (captions per platform as lists — one per account, rule_used, engine_used).
    A manually written caption is used for the first account of that platform; extra accounts
    get variations so the same text isn't posted twice.
    """
    manual = {k: v for k, v in (manual or {}).items() if v and v.strip()}
    if mode == "none":
        return {k: [""] * n for k, n in counts.items()}, rule, "none"
    if mode == "manual":
        return {k: [manual.get(k, manual.get("all", ""))] * n for k, n in counts.items()}, rule, "manual"

    need = {k: n - (1 if k in manual else 0) for k, n in counts.items()}
    generated, engine = {}, "template"
    if mode == "ai" and ai_available() and any(need.values()):
        try:
            frames = await frames_fn() if (not rule and frames_fn) else None
            generated, rule = await ai_captions(rule, episode, need, frames)
            engine = "ai"
        except Exception as e:                       # never block a post on the AI
            log.warning("AI captions failed, using template: %s", e)
            generated = {}
    out = {}
    for k, n in counts.items():
        caps = [manual[k]] if k in manual else []
        caps += generated.get(k) or [template_caption(rule, k, episode) for _ in range(need[k])]
        out[k] = caps[:n]
    return out, rule, engine
