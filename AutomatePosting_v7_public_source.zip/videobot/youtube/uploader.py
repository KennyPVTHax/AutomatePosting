"""
YouTube Shorts uploader — one token file per channel.

Authorising a channel (headless-friendly, replaces Google's retired copy-paste "oob" flow):
  1. auth_url() gives a Google link → open it, pick the channel's Google account, allow.
  2. The browser lands on http://localhost/... and shows "can't connect" — that's expected.
     Copy that whole address and hand it to finish_auth(). Done.
Use an OAuth client of type "Desktop app" in Google Cloud Console.
"""
import asyncio
import logging
import os
from urllib.parse import parse_qs, urlparse

import config

log = logging.getLogger(__name__)

SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]
REDIRECT = "http://localhost"
os.makedirs(os.path.join(config.BASE_DIR, "youtube", "tokens"), exist_ok=True)

_pending_flows: dict[str, object] = {}       # channel id → Flow awaiting its code


class YouTubeUploader:
    def __init__(self, channel: dict):
        self.channel    = channel
        self.token_file = os.path.join(config.BASE_DIR, channel["token_file"])
        self.creds_file = os.path.join(config.BASE_DIR, channel.get("client_secret") or "")

    def needs_auth(self) -> bool:
        return not os.path.exists(self.token_file)

    def auth_url(self) -> str:
        from google_auth_oauthlib.flow import Flow
        if not os.path.isfile(self.creds_file):
            raise RuntimeError("Upload this channel's client_secret.json first.")
        flow = Flow.from_client_secrets_file(self.creds_file, scopes=SCOPES, redirect_uri=REDIRECT)
        url, _ = flow.authorization_url(prompt="consent", access_type="offline")
        _pending_flows[self.channel["id"]] = flow
        return url

    def finish_auth(self, pasted: str) -> None:
        flow = _pending_flows.get(self.channel["id"])
        if flow is None:
            raise RuntimeError("That link expired — start the authorisation again.")
        pasted = pasted.strip()
        code = pasted
        if "code=" in pasted:
            code = parse_qs(urlparse(pasted).query).get("code", [""])[0]
        if not code:
            raise RuntimeError("No code found. Paste the full address your browser ended up on.")
        flow.fetch_token(code=code)
        os.makedirs(os.path.dirname(self.token_file), exist_ok=True)
        with open(self.token_file, "w") as f:
            f.write(flow.credentials.to_json())
        os.chmod(self.token_file, 0o600)
        _pending_flows.pop(self.channel["id"], None)

    async def post(self, video_path: str, caption: str) -> dict:
        if self.needs_auth():
            raise RuntimeError("Channel not authorised yet — connect it in Accounts (or /addyt).")
        vid = await asyncio.to_thread(self._upload_sync, video_path, caption)
        return {"id": vid, "url": f"https://youtube.com/shorts/{vid}"}

    def _upload_sync(self, video_path: str, caption: str) -> str:
        from google.auth.transport.requests import Request
        from google.oauth2.credentials import Credentials
        from googleapiclient.discovery import build
        from googleapiclient.http import MediaFileUpload

        creds = Credentials.from_authorized_user_file(self.token_file, SCOPES)
        if not creds.valid and creds.refresh_token:
            creds.refresh(Request())
            with open(self.token_file, "w") as f:
                f.write(creds.to_json())

        youtube = build("youtube", "v3", credentials=creds, cache_discovery=False)
        caption = caption or "🎮 #Roblox #Shorts"
        title = caption.split("\n")[0].replace("<", "").replace(">", "").strip()[:100] or "New Short"
        if "#shorts" not in caption.lower():
            caption += "\n#Shorts"
        tags = [w.lstrip("#") for w in caption.split() if w.startswith("#")][:15]
        body = {
            "snippet": {"title": title, "description": caption.replace("<", "").replace(">", "")[:5000],
                        "tags": tags, "categoryId": "20"},
            "status": {"privacyStatus": "public", "selfDeclaredMadeForKids": False},
        }
        upload = MediaFileUpload(video_path, mimetype="video/mp4", resumable=True, chunksize=8 * 1024 * 1024)
        req = youtube.videos().insert(part="snippet,status", body=body, media_body=upload)
        response = None
        while response is None:
            _, response = req.next_chunk(num_retries=3)
        log.info("[%s] YouTube uploaded %s", self.channel["name"], response["id"])
        return response["id"]
