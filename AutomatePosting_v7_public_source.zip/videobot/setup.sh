#!/bin/bash
# One-time VPS setup: installs FFmpeg + nginx, creates the Python venv and a systemd service.
set -e
cd "$(dirname "$0")"
DIR="$(pwd)"

echo "[1/4] System packages…"
sudo apt-get update -qq
sudo apt-get install -y -qq ffmpeg nginx python3 python3-venv

echo "[2/4] Python environment…"
python3 -m venv venv
./venv/bin/pip install -q --upgrade pip
./venv/bin/pip install -q -r requirements.txt

echo "[3/4] nginx (serves processed videos to Instagram)…"
sudo mkdir -p /var/www/html/videos
sudo chown "$USER" /var/www/html/videos
sudo tee /etc/nginx/sites-available/videobot > /dev/null <<'NGINX'
server {
    listen 80;
    server_name _;
    location /videos/ { alias /var/www/html/videos/; }
}
NGINX
sudo ln -sf /etc/nginx/sites-available/videobot /etc/nginx/sites-enabled/videobot
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

echo "[4/4] systemd service…"
[ -f .env ] || { cp .env.example .env; chmod 600 .env; }
[ -f channels.json ] || cp channels.example.json channels.json
sudo tee /etc/systemd/system/videobot.service > /dev/null <<SERVICE
[Unit]
Description=VideoBot (Telegram bot + dashboard + scheduler)
After=network-online.target
Wants=network-online.target

[Service]
WorkingDirectory=$DIR
ExecStart=$DIR/venv/bin/python run.py
Restart=always
RestartSec=5
User=$USER

[Install]
WantedBy=multi-user.target
SERVICE
sudo systemctl daemon-reload
sudo systemctl enable videobot

cat <<DONE

Setup complete.

  1. nano .env                       ← BOT_TOKEN, OWNER_ID, VPS_PUBLIC_URL, GEMINI_API_KEY
  2. sudo systemctl restart videobot
  3. In Telegram send /start, then /dashboard for the web link and password.

Logs: sudo journalctl -u videobot -f
DONE
