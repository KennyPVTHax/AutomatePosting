"""
Web dashboard (FastAPI). Runs inside the same process as the bot, so both share one queue.
Everything under /api needs the dashboard password; account tokens are never sent to the browser.
"""
import asyncio
import hashlib
import hmac
import json
import os
import time
import uuid
import sys
from urllib.parse import urlsplit
from datetime import datetime

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse

import captions
import channel_manager as cm
import config
from pipeline import Pipeline, fmt_time, public_job, tz
from store import ACTIVE

STATIC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
COOKIE = "vb_session"
MAX_ASSET = 60 * 1024 * 1024
MAX_IMPORT_BYTES = 1500 * 1024 * 1024
IMPORT_TIMEOUT_SECONDS = 900
# Only known public platform URLs: never run a generic extractor against arbitrary destinations.
ALLOWED_VIDEO_HOSTS = {
    "youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be", "www.youtu.be",
    "instagram.com", "www.instagram.com", "facebook.com", "www.facebook.com",
    "m.facebook.com", "web.facebook.com", "fb.watch", "www.fb.watch",
}



def _session_token() -> str:
    return hmac.new(config.DASH_PASSWORD.encode(), b"videobot-session", hashlib.sha256).hexdigest()


async def _save_upload(upload: UploadFile, dest: str, limit: int | None = None) -> None:
    size = 0
    with open(dest, "wb") as f:
        while chunk := await upload.read(1024 * 1024):
            size += len(chunk)
            if limit and size > limit:
                f.close()
                os.remove(dest)
                raise HTTPException(413, "That file is too large.")
            f.write(chunk)


def create_app(pipeline: Pipeline) -> FastAPI:
    app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
    store = pipeline.store
    imports: dict[str, dict] = {}
    import_lock = asyncio.Lock()

    def import_record(import_id: str) -> dict:
        record = imports.get(import_id)
        if not record or time.time() - record["created"] > 3600:
            raise HTTPException(404, "Import expired. Please import again.")
        return record

    async def download_url(import_id: str, url: str) -> None:
        record = imports[import_id]
        prefix = os.path.join(config.UPLOAD_DIR, "import_" + import_id)
        args = [sys.executable, "-m", "yt_dlp", "--no-config", "--no-playlist",
                "--no-warnings", "--no-progress", "--no-cache-dir",
                "--max-filesize", "1500M", "--socket-timeout", "25", "--retries", "2",
                "--match-filter", "duration <= 14400", "-f", "bv*+ba/b",
                "--merge-output-format", "mp4", "-o", prefix + ".%(ext)s", "--", url]
        proc = None
        try:
            proc = await asyncio.create_subprocess_exec(*args, stdout=asyncio.subprocess.DEVNULL,
                                                          stderr=asyncio.subprocess.PIPE)
            _, err = await asyncio.wait_for(proc.communicate(), timeout=IMPORT_TIMEOUT_SECONDS)
            matches = [name for name in os.listdir(config.UPLOAD_DIR)
                       if name.startswith("import_" + import_id + ".") and not name.endswith(".part")]
            if proc.returncode != 0 or len(matches) != 1:
                detail = (err or b"").decode(errors="replace").strip()[-300:]
                raise RuntimeError("Download not available. " + detail)
            file_path = os.path.join(config.UPLOAD_DIR, matches[0])
            if os.path.getsize(file_path) > MAX_IMPORT_BYTES:
                raise RuntimeError("Video exceeds the 1.5 GB import limit.")
            if os.path.splitext(file_path)[1].lower() not in (config.VIDEO_EXTS | {".m4v", ".avi"}):
                raise RuntimeError("Unsupported downloaded video format.")
            record.update(status="ready", path=file_path, size=os.path.getsize(file_path))
        except Exception as exc:
            if proc and proc.returncode is None:
                proc.kill()
                await proc.wait()
            record.update(status="failed", error=str(exc)[:400])
            for name in os.listdir(config.UPLOAD_DIR):
                if name.startswith("import_" + import_id + "."):
                    try: os.remove(os.path.join(config.UPLOAD_DIR, name))
                    except OSError: pass

    @app.post("/api/imports")
    async def start_import(request: Request):
        data = await request.json()
        url = str(data.get("url", "")).strip()
        try:
            parsed = urlsplit(url)
            hostname = (parsed.hostname or "").lower()
            if (parsed.scheme != "https" or parsed.username or parsed.password or
                    parsed.port not in (None, 443) or hostname not in ALLOWED_VIDEO_HOSTS or
                    len(url) > 2048):
                raise ValueError()
        except (ValueError, TypeError):
            raise HTTPException(400, "Use a public HTTPS YouTube, Instagram or Facebook video URL.")
        async with import_lock:
            if sum(r["status"] == "downloading" for r in imports.values()) >= 1:
                raise HTTPException(429, "Another import is running. Try again after it finishes.")
            import_id = uuid.uuid4().hex
            imports[import_id] = {"status": "downloading", "created": time.time(), "error": ""}
            asyncio.create_task(download_url(import_id, url))
        return {"id": import_id, "status": "downloading"}

    @app.get("/api/imports/{import_id}")
    def import_status(import_id: str):
        r = import_record(import_id)
        return {k: r.get(k) for k in ("status", "error", "size")}

    @app.get("/api/imports/{import_id}/preview")
    def import_preview(import_id: str):
        r = import_record(import_id)
        if r["status"] != "ready" or not os.path.isfile(r["path"]):
            raise HTTPException(404, "Video not ready")
        return FileResponse(r["path"], media_type="video/mp4", headers={"Cache-Control": "no-store"})

    @app.middleware("http")
    async def auth(request: Request, call_next):
        path = request.url.path
        protected = path.startswith("/api/") and path != "/api/login" or path.startswith("/asset/")
        if protected and not hmac.compare_digest(request.cookies.get(COOKIE, ""), _session_token()):
            return JSONResponse({"detail": "Sign in first."}, status_code=401)
        return await call_next(request)

    # ── pages ─────────────────────────────────────────────────────────────
    @app.get("/")
    def index():
        return FileResponse(os.path.join(STATIC, "index.html"), headers={"Cache-Control": "no-cache"})

    @app.get("/manifest.json")
    def manifest():
        return {"name": "VideoBot", "short_name": "VideoBot", "start_url": "/", "display": "standalone",
                "background_color": "#16121D", "theme_color": "#16121D",
                "icons": [{"src": "/icon.svg", "sizes": "any", "type": "image/svg+xml"}]}

    @app.get("/icon.svg")
    def icon():
        return FileResponse(os.path.join(STATIC, "icon.svg"), media_type="image/svg+xml")

    @app.get("/videos/{name}")
    def public_video(name: str):
        """Public on purpose: Instagram downloads the reel from here. Names are random and short-lived."""
        path = os.path.join(config.SERVE_DIR, config.safe_name(name))
        if not os.path.isfile(path):
            raise HTTPException(404)
        return FileResponse(path, media_type="video/mp4")

    # ── session ───────────────────────────────────────────────────────────
    @app.post("/api/login")
    async def login(password: str = Form(...)):
        if not hmac.compare_digest(password.strip().encode(), config.DASH_PASSWORD.encode()):
            await asyncio.sleep(1.5)
            raise HTTPException(401, "Wrong password.")
        resp = JSONResponse({"ok": True})
        resp.set_cookie(COOKIE, _session_token(), max_age=60 * 86400, httponly=True, samesite="strict", secure=True)
        return resp

    @app.post("/api/logout")
    def logout():
        resp = JSONResponse({"ok": True})
        resp.delete_cookie(COOKIE)
        return resp

    # ── state ─────────────────────────────────────────────────────────────
    def open_slots(n: int = 4) -> list[dict]:
        out, after = [], time.time()
        if not store.get_settings()["slots"]:
            return out
        taken = set()
        while len(out) < n:
            ts = pipeline.next_slot(after)
            if ts <= after or ts in taken:
                break
            taken.add(ts)
            out.append({"ts": ts, "label": fmt_time(ts)})
            after = ts
        return out

    @app.get("/api/state")
    def state():
        return {
            "settings": store.get_settings(),
            "accounts": cm.flat_accounts(),
            "logos": config.list_assets("logo"),
            "endings": config.list_assets("ending"),
            "ai": captions.ai_available(),
            "timezone": config.TIMEZONE,
            "public_url": bool(config.VPS_PUBLIC_URL),
            "bot": bool(config.BOT_TOKEN),
        }

    @app.get("/api/jobs")
    def jobs():
        all_jobs = store.list_jobs(limit=60)
        return {"jobs": [public_job(j) for j in all_jobs if j["status"] != "draft"],
                "open_slots": open_slots(), "now": time.time()}

    @app.put("/api/settings")
    async def put_settings(request: Request):
        body = await request.json()
        if "slots" in body:
            clean = []
            for s in body["slots"]:
                try:
                    h, m = str(s).split(":")
                    assert 0 <= int(h) < 24 and 0 <= int(m) < 60
                    clean.append(f"{int(h):02d}:{int(m):02d}")
                except (ValueError, AssertionError):
                    raise HTTPException(400, f"“{s}” is not a time. Use HH:MM.")
            body["slots"] = sorted(set(clean))
        if "episode" in body:
            body["episode"] = max(1, int(body["episode"]))
        if body.get("caption_mode") not in (None, "ai", "template", "manual", "none"):
            raise HTTPException(400, "Unknown caption style.")
        if body.get("autopilot") and not (body.get("default_targets") or store.get_settings()["default_targets"]):
            raise HTTPException(400, "Choose at least one account for Autopilot to post to.")
        return store.update_settings(**body)

    # ── captions ──────────────────────────────────────────────────────────
    @app.post("/api/caption")
    async def caption(rule: str = Form(""), episode: int = Form(1), mode: str = Form("ai")):
        counts = {"yt": 1, "ig": 1, "fb": 1}
        caps, rule_used, engine = await captions.build_captions(
            "ai" if mode == "ai" else "template", rule.strip(), episode, counts)
        return {"yt": caps["yt"][0], "ig": caps["ig"][0], "fb": caps["fb"][0], "engine": engine,
                "note": "" if engine == mode or mode != "ai" else
                        "The AI wasn't available, so these came from the template."}

    # ── jobs ──────────────────────────────────────────────────────────────
    @app.post("/api/jobs")
    async def create_job(
        video: UploadFile | None = File(None), import_id: str = Form(""),
        speed: float = Form(1.02), contrast: float = Form(1.01),
        logo_position: str = Form("top-right"), logo: str = Form(""), ending: str = Form(""),
        rule: str = Form(""), episode: int = Form(0), caption_mode: str = Form("ai"),
        captions_json: str = Form("{}"), targets: str = Form("[]"), when: str = Form("now"),
    ):
        if not (0.75 <= speed <= 1.5 and 0.98 <= contrast <= 1.04):
            raise HTTPException(400, "Speed or contrast is outside the allowed range.")
        if logo_position not in ("top-right", "top-left", "bottom-right", "bottom-left"):
            raise HTTPException(400, "Invalid watermark position.")
        if bool(video) == bool(import_id):
            raise HTTPException(400, "Choose one source: an uploaded video or an imported URL.")
        if import_id:
            r = import_record(import_id)
            if r["status"] != "ready" or not os.path.isfile(r["path"]):
                raise HTTPException(400, "URL import is not ready.")
            dest = r["path"]
        else:
            ext = os.path.splitext(video.filename or "")[1].lower()
            if ext not in config.VIDEO_EXTS | {".m4v", ".avi"}:
                raise HTTPException(400, "Choose a video file (MP4, MOV, WebM or MKV).")
            dest = os.path.join(config.UPLOAD_DIR, f"web_{uuid.uuid4().hex}{ext}")
            await _save_upload(video, dest)
        try:
            manual = {k: v for k, v in json.loads(captions_json).items() if k in ("yt", "ig", "fb", "all") and v}
            keys = [str(k) for k in json.loads(targets)]
        except (ValueError, AttributeError):
            raise HTTPException(400, "Bad request.")
        job = pipeline.new_job(
            dest, "web", logo=config.safe_name(logo) if logo else "", ending=config.safe_name(ending) if ending else "",
            rule=rule.strip(), episode=episode, caption_mode=caption_mode, captions=manual,
            targets=pipeline.expand_targets(keys), speed=speed, contrast=contrast,
            logo_position=logo_position)
        if when == "now":
            run_at = None
        elif when == "slot":
            run_at = pipeline.next_slot()
        else:
            try:
                run_at = datetime.fromisoformat(when).replace(tzinfo=tz()).timestamp()
            except ValueError:
                raise HTTPException(400, "Bad date.")
            if run_at < time.time():
                run_at = None
        if import_id:
            imports.pop(import_id, None)
        return public_job(pipeline.schedule(job, run_at))

    @app.post("/api/jobs/{job_id}/{action}")
    def job_action(job_id: int, action: str):
        job = store.get_job(job_id)
        if not job:
            raise HTTPException(404, "That video is no longer in the queue.")
        if action == "now" and job["status"] == "scheduled":
            job = pipeline.schedule(job, None)
        elif action == "cancel":
            job = pipeline.cancel(job_id)
        elif action == "retry":
            job = pipeline.retry_failed(job_id)
        elif action == "delete" and job["status"] not in ACTIVE:
            for key in ("input_path", "output_path"):
                if job.get(key) and os.path.exists(job[key]):
                    os.remove(job[key])
            store.delete_job(job_id)
            return {"ok": True}
        else:
            raise HTTPException(400, "Can't do that right now.")
        return public_job(job)

    @app.get("/api/jobs/{job_id}/download")
    def download(job_id: int):
        job = store.get_job(job_id)
        if not job or not job.get("output_path") or not os.path.exists(job["output_path"]):
            raise HTTPException(404, "The file has been cleaned up. Processed videos are kept for 24 hours.")
        return FileResponse(job["output_path"], media_type="video/mp4", filename=f"videobot_{job_id}.mp4")

    # ── assets ────────────────────────────────────────────────────────────
    @app.get("/asset/{kind}/{name}")
    def asset(kind: str, name: str):
        path = config.asset_path("logo" if kind == "logo" else "ending", name)
        if not path:
            raise HTTPException(404)
        return FileResponse(path)

    @app.post("/api/assets")
    async def upload_asset(kind: str = Form(...), file: UploadFile = File(...)):
        kind = "logo" if kind == "logo" else "ending"
        name = config.safe_name(file.filename or "", "asset.png")
        ext = os.path.splitext(name)[1].lower()
        allowed = config.IMAGE_EXTS if kind == "logo" else config.IMAGE_EXTS | config.VIDEO_EXTS
        if ext not in allowed:
            raise HTTPException(400, "Logos must be images. Endings can be an image or a short video.")
        directory = config.LOGOS_DIR if kind == "logo" else config.ENDINGS_DIR
        await _save_upload(file, os.path.join(directory, name), MAX_ASSET)
        return {"saved": name}

    @app.delete("/api/assets/{kind}/{name}")
    def delete_asset(kind: str, name: str):
        path = config.asset_path("logo" if kind == "logo" else "ending", name)
        if not path:
            raise HTTPException(404, "Already gone.")
        os.remove(path)
        return {"ok": True}

    # ── accounts ──────────────────────────────────────────────────────────
    @app.post("/api/accounts/ig")
    def add_ig(name: str = Form(...), access_token: str = Form(...), user_id: str = Form(...), pair_yt: str = Form("")):
        acc_id = cm.make_id(name)
        result = cm.add_ig_account(acc_id, name.strip(), access_token.strip(), user_id.strip())
        if pair_yt:
            cm.pair(pair_yt, ig_id=acc_id)
        return {"result": result, "id": acc_id}

    @app.post("/api/accounts/fb")
    def add_fb(name: str = Form(...), page_id: str = Form(...), access_token: str = Form(...), pair_yt: str = Form("")):
        acc_id = cm.make_id(name)
        result = cm.add_fb_account(acc_id, name.strip(), page_id.strip(), access_token.strip())
        if pair_yt:
            cm.pair(pair_yt, fb_id=acc_id)
        return {"result": result, "id": acc_id}

    @app.post("/api/accounts/yt")
    async def add_yt(name: str = Form(...), client_secret: UploadFile | None = File(None)):
        ch_id = cm.make_id(name)
        existing = cm.get_account("yt", ch_id) or {}
        rel = existing.get("client_secret", "")
        if client_secret is not None and client_secret.filename:
            rel = f"youtube/client_secret_{ch_id}.json"
            path = os.path.join(config.BASE_DIR, rel)
            await _save_upload(client_secret, path, 1024 * 1024)
            try:
                json.load(open(path))
            except ValueError:
                os.remove(path)
                raise HTTPException(400, "That isn't a valid client_secret.json.")
            os.chmod(path, 0o600)
        if not rel:
            shared = "youtube/client_secret.json"
            if not os.path.exists(os.path.join(config.BASE_DIR, shared)):
                raise HTTPException(400, "Attach the client_secret.json from Google Cloud Console.")
            rel = shared
        cm.add_yt_channel(ch_id, name.strip(), rel)
        return {"id": ch_id}

    @app.post("/api/accounts/yt/{ch_id}/auth-url")
    def yt_auth_url(ch_id: str):
        from youtube.uploader import YouTubeUploader
        ch = cm.get_account("yt", ch_id)
        if not ch:
            raise HTTPException(404, "Channel not found.")
        try:
            return {"url": YouTubeUploader(ch).auth_url()}
        except Exception as e:
            raise HTTPException(400, str(e))

    @app.post("/api/accounts/yt/{ch_id}/auth-code")
    async def yt_auth_code(ch_id: str, code: str = Form(...)):
        from youtube.uploader import YouTubeUploader
        ch = cm.get_account("yt", ch_id)
        if not ch:
            raise HTTPException(404, "Channel not found.")
        try:
            await asyncio.to_thread(YouTubeUploader(ch).finish_auth, code)
        except Exception as e:
            raise HTTPException(400, str(e))
        return {"ok": True}

    @app.delete("/api/accounts/{kind}/{acc_id}")
    def delete_account(kind: str, acc_id: str):
        if kind not in cm.KEYS:
            raise HTTPException(404)
        cm.remove_account(kind, acc_id)
        s = store.get_settings()
        store.update_settings(default_targets=[k for k in s["default_targets"] if k != f"{kind}:{acc_id}"])
        return {"ok": True}

    return app
