"""Instagram Reels via the Graph API. Multi-account; tokens come from channels.json."""
import asyncio
import logging
import time

import aiohttp

import channel_manager
import media

log = logging.getLogger(__name__)
BASE = "https://graph.instagram.com/v21.0"
TIMEOUT = aiohttp.ClientTimeout(total=60)


def _err(d: dict) -> str:
    e = d.get("error", {}) if isinstance(d, dict) else {}
    return e.get("error_user_msg") or e.get("message") or str(d)[:300]


class InstagramPoster:
    def __init__(self, account: dict):
        self.account = account
        self.token   = account["access_token"]
        self.user_id = account["user_id"]

    async def post(self, video_path: str, caption: str) -> dict:
        url, public_copy = media.publish(video_path)
        try:
            async with aiohttp.ClientSession(timeout=TIMEOUT) as s:
                async with s.post(f"{BASE}/{self.user_id}/media", params={
                        "media_type": "REELS", "video_url": url, "caption": caption,
                        "share_to_feed": "true", "access_token": self.token}) as r:
                    d = await r.json(content_type=None)
                if "id" not in d:
                    raise RuntimeError(f"Instagram refused the upload: {_err(d)}")
                container = d["id"]

                deadline = time.time() + 420
                delay = 4
                while True:
                    await asyncio.sleep(delay)
                    delay = min(delay + 2, 10)
                    async with s.get(f"{BASE}/{container}", params={
                            "fields": "status_code,status", "access_token": self.token}) as r:
                        d = await r.json(content_type=None)
                    code = d.get("status_code", "")
                    if code == "FINISHED":
                        break
                    if code in ("ERROR", "EXPIRED"):
                        raise RuntimeError(f"Instagram could not process the video: {d.get('status') or _err(d)}")
                    if time.time() > deadline:
                        raise TimeoutError("Instagram took too long to process the video")

                async with s.post(f"{BASE}/{self.user_id}/media_publish", params={
                        "creation_id": container, "access_token": self.token}) as r:
                    d = await r.json(content_type=None)
                if "id" not in d:
                    raise RuntimeError(f"Instagram publish failed: {_err(d)}")
                media_id, link = d["id"], ""
                try:
                    async with s.get(f"{BASE}/{media_id}", params={
                            "fields": "permalink", "access_token": self.token}) as r:
                        link = (await r.json(content_type=None)).get("permalink", "")
                except Exception:
                    pass
            log.info("[%s] Instagram posted %s", self.account["name"], media_id)
            return {"id": media_id, "url": link}
        finally:
            media.unpublish(public_copy)


async def refresh_token(account: dict) -> bool:
    """Extend a long-lived token by another 60 days. Saves the new token."""
    async with aiohttp.ClientSession(timeout=TIMEOUT) as s:
        async with s.get("https://graph.instagram.com/refresh_access_token", params={
                "grant_type": "ig_refresh_token", "access_token": account["access_token"]}) as r:
            d = await r.json(content_type=None)
    if "access_token" not in d:
        raise RuntimeError(_err(d))
    channel_manager.update_account(
        "ig", account["id"], access_token=d["access_token"], refreshed_at=time.time(),
        expires_at=time.time() + int(d.get("expires_in", 0)))
    return True
