"""
The engine both the Telegram bot and the dashboard drive.

  draft → scheduled → processing → posting → done | partial | failed   (or cancelled)

- One video is encoded at a time (CPU), all accounts are posted to in parallel.
- Each account gets up to 3 attempts with backoff; failures can be retried later without re-encoding.
- Jobs are stored in SQLite, so a restart resumes the queue instead of losing it.
- Autopilot: jobs are dropped onto the next free daily slot and go out on their own.
"""
import asyncio
import logging
import os
import time
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import captions
import channel_manager
import config
import media
from processing.processor import VideoProcessor
from store import ACTIVE, Store

log = logging.getLogger(__name__)

RETRY_DELAYS = (0, 20, 60)          # seconds before attempt 1, 2, 3
KEEP_FILES_FOR = 24 * 3600          # processed videos stay downloadable for a day
KEEP_JOBS_FOR = 30 * 24 * 3600
PERMANENT_HINTS = ("not authorised", "not found", "not set", "invalid oauth", "access token",
                   "permission", "client_secret")


def tz() -> ZoneInfo:
    try:
        return ZoneInfo(config.TIMEZONE)
    except Exception:
        return ZoneInfo("UTC")


def fmt_time(ts: float | None) -> str:
    if not ts:
        return "now"
    dt, now = datetime.fromtimestamp(ts, tz()), datetime.now(tz())
    day = "today" if dt.date() == now.date() else \
          "tomorrow" if dt.date() == (now + timedelta(days=1)).date() else dt.strftime("%a %d %b")
    return f"{day} {dt.strftime('%H:%M')}"


def make_poster(kind: str, account: dict):
    if kind == "yt":
        from youtube.uploader import YouTubeUploader
        return YouTubeUploader(account)
    if kind == "ig":
        from instagram.poster import InstagramPoster
        return InstagramPoster(account)
    if kind == "fb":
        from facebook.poster import FacebookPoster
        return FacebookPoster(account)
    raise ValueError(kind)


class Pipeline:
    def __init__(self, store: Store | None = None):
        self.store = store or Store()
        self.processor = VideoProcessor()
        self.listeners: list = []           # async fn(job) — called on every job change
        self.notifiers: list = []           # async fn(text) — owner alerts
        self._encode_lock = asyncio.Semaphore(1)
        self._running: dict[int, asyncio.Task] = {}
        self._wake = asyncio.Event()
        self._last_emit: dict[int, float] = {}

    # ── building jobs ─────────────────────────────────────────────────────
    def expand_targets(self, keys: list[str]) -> list[dict]:
        names = {a["key"]: a["name"] for a in channel_manager.flat_accounts()}
        out, seen = [], set()
        for key in keys:
            if key in names and key not in seen:
                seen.add(key)
                kind, acc_id = key.split(":", 1)
                out.append({"type": kind, "id": acc_id, "name": names[key],
                            "status": "pending", "url": "", "error": "", "attempts": 0})
        return out

    def new_job(self, input_path: str, source: str, **over) -> dict:
        s = self.store.get_settings()
        data = {
            "input_path": input_path, "source": source,
            "logo": s["default_logo"] if config.asset_path("logo", s["default_logo"]) else "",
            "ending": s["default_ending"] if config.asset_path("ending", s["default_ending"]) else "",
            "caption_mode": s["caption_mode"],
            "targets": self.expand_targets(s["default_targets"]),
        }
        data.update(over)
        return self.store.create_job(**data)

    def next_slot(self, after: float | None = None) -> float:
        """Next free daily slot. With no slots configured, that's simply 'now'."""
        after = after or time.time()
        slots = []
        for s in self.store.get_settings()["slots"]:
            try:
                h, m = s.split(":")
                slots.append((int(h), int(m)))
            except ValueError:
                continue
        if not slots:
            return after
        taken = {int(j["run_at"]) for j in self.store.list_jobs(("scheduled",), 500) if j.get("run_at")}
        day = datetime.fromtimestamp(after, tz()).replace(second=0, microsecond=0)
        for offset in range(120):
            base = day + timedelta(days=offset)
            for h, m in sorted(slots):
                ts = base.replace(hour=h, minute=m).timestamp()
                if ts > after + 30 and int(ts) not in taken:
                    return ts
        return after

    def schedule(self, job: dict, run_at: float | None) -> dict:
        """run_at=None → as soon as possible."""
        if not job.get("episode_assigned"):
            if job["targets"]:                          # download-only edits don't use up an episode number
                job["episode"] = int(job.get("episode") or 0) or self.store.take_episode()
            else:
                job["episode"] = int(job.get("episode") or 0) or int(self.store.get_settings()["episode"])
            job["episode_assigned"] = True
        job.update(status="scheduled", run_at=run_at, error="", progress=0,
                   message="Queued" if not run_at else f"Scheduled for {fmt_time(run_at)}")
        self.store.save_job(job)
        self._wake.set()
        self._emit_soon(job)
        return job

    def cancel(self, job_id: int) -> dict | None:
        job = self.store.get_job(job_id)
        if not job:
            return None
        task = self._running.pop(job_id, None)
        if task:
            task.cancel()
        if job["status"] in ("draft", *ACTIVE):
            job.update(status="cancelled", message="Cancelled", finished_at=time.time())
            self.store.save_job(job)
            self._emit_soon(job)
        return job

    def retry_failed(self, job_id: int) -> dict | None:
        job = self.store.get_job(job_id)
        if not job or job["status"] in ACTIVE:
            return job
        for t in job["targets"]:
            if t["status"] != "ok":
                t.update(status="pending", error="", attempts=0)
        return self.schedule(job, None)

    # ── events ────────────────────────────────────────────────────────────
    def _emit_soon(self, job: dict) -> None:
        try:
            asyncio.get_running_loop().create_task(self._emit(job, force=True))
        except RuntimeError:
            pass

    async def _emit(self, job: dict, force: bool = False) -> None:
        now = time.monotonic()
        if not force and now - self._last_emit.get(job["id"], 0) < 2.5:
            return
        self._last_emit[job["id"]] = now
        for fn in self.listeners:
            try:
                await fn(job)
            except Exception:
                log.exception("listener failed")

    async def notify(self, text: str) -> None:
        for fn in self.notifiers:
            try:
                await fn(text)
            except Exception:
                log.exception("notifier failed")

    # ── running a job ─────────────────────────────────────────────────────
    async def _run(self, job_id: int) -> None:
        job = self.store.get_job(job_id)
        if not job or job["status"] != "scheduled":
            return
        try:
            await self._process(job)
            if job["targets"]:
                await self._captions(job)
                await self._post(job)
            ok = [t for t in job["targets"] if t["status"] == "ok"]
            bad = [t for t in job["targets"] if t["status"] != "ok"]
            job["status"] = "done" if not bad else ("partial" if ok else "failed")
            job["message"] = ("Ready to download" if not job["targets"] else
                              f"Posted to {len(ok)} of {len(job['targets'])}" if bad else "Posted")
        except asyncio.CancelledError:
            return
        except Exception as e:
            log.exception("job %s failed", job_id)
            job.update(status="failed", error=str(e)[-500:], message="Failed")
        finally:
            self._running.pop(job_id, None)
        job.update(finished_at=time.time(), progress=100 if job["status"] != "failed" else job["progress"])
        self.store.save_job(job)
        await self._emit(job, force=True)

    async def _process(self, job: dict) -> None:
        if job.get("output_path") and os.path.exists(job["output_path"]):
            return                                           # retry: already encoded
        if not os.path.exists(job["input_path"]):
            raise RuntimeError("The original video is gone — send it again.")
        job.update(status="processing", message="Waiting for the encoder", progress=0)
        self.store.save_job(job)
        await self._emit(job, force=True)
        out = os.path.join(config.OUTPUT_DIR, f"job_{job['id']}.mp4")

        async def on_progress(pct: int) -> None:
            job.update(progress=pct, message="Encoding")
            await self._emit(job)

        async with self._encode_lock:
            await self.processor.process(
                job["input_path"], out + ".part.mp4",
                logo_path=config.asset_path("logo", job["logo"]),
                ending_path=config.asset_path("ending", job["ending"]),
                speed=job.get("speed", config.SPEED), contrast=job.get("contrast", 1.0),
                logo_position=job.get("logo_position", "top-right"),
                on_progress=on_progress)
        os.replace(out + ".part.mp4", out)
        job["output_path"] = out
        self.store.save_job(job)

    async def _captions(self, job: dict) -> None:
        todo = [t for t in job["targets"] if t["status"] != "ok" and not t.get("caption")]
        if not todo:
            return
        job.update(status="posting", message="Writing captions")
        await self._emit(job, force=True)
        counts: dict[str, int] = {}
        for t in todo:
            counts[t["type"]] = counts.get(t["type"], 0) + 1
        caps, rule, engine = await captions.build_captions(
            job["caption_mode"], job.get("rule", ""), int(job.get("episode") or 1), counts,
            manual=job.get("captions"), frames_fn=lambda: self.processor.frames(job["input_path"]))
        job["rule"], job["caption_engine"] = rule, engine
        for t in todo:
            t["caption"] = caps[t["type"]].pop(0)
        self.store.save_job(job)

    async def _post(self, job: dict) -> None:
        job.update(status="posting", message="Posting")
        self.store.save_job(job)
        await self._emit(job, force=True)

        async def one(t: dict) -> None:
            account = channel_manager.get_account(t["type"], t["id"])
            if not account:
                t.update(status="failed", error="This account was removed.")
                return
            for attempt, delay in enumerate(RETRY_DELAYS, 1):
                if delay:
                    await asyncio.sleep(delay)
                t.update(status="posting", attempts=attempt)
                await self._emit(job, force=True)
                try:
                    res = await make_poster(t["type"], account).post(job["output_path"], t.get("caption", ""))
                    t.update(status="ok", url=res.get("url", ""), post_id=str(res.get("id", "")), error="")
                    break
                except Exception as e:
                    msg = str(e)[-300:] or type(e).__name__
                    log.warning("post to %s failed (attempt %d): %s", t["name"], attempt, msg)
                    t.update(status="failed", error=msg)
                    if any(h in msg.lower() for h in PERMANENT_HINTS):
                        break                               # retrying won't fix a bad token
            self.store.save_job(job)
            await self._emit(job, force=True)

        await asyncio.gather(*(one(t) for t in job["targets"] if t["status"] != "ok"))

    # ── background loops ──────────────────────────────────────────────────
    def recover(self) -> None:
        """After a restart: anything that was mid-flight goes back in the queue."""
        for job in self.store.list_jobs(("processing", "posting"), 500):
            for t in job["targets"]:
                if t["status"] == "posting":
                    t["status"] = "pending"
            job.update(status="scheduled", run_at=None, message="Resuming after restart")
            self.store.save_job(job)

    async def run_forever(self) -> None:
        self.recover()
        last_housekeeping = 0.0
        while True:
            try:
                for job in self.store.due_jobs(time.time()):
                    if job["id"] not in self._running:
                        self._running[job["id"]] = asyncio.create_task(self._run(job["id"]))
                if time.time() - last_housekeeping > 3600:
                    last_housekeeping = time.time()
                    await self._housekeeping()
            except Exception:
                log.exception("scheduler tick failed")
            self._wake.clear()
            try:
                await asyncio.wait_for(self._wake.wait(), timeout=10)
            except asyncio.TimeoutError:
                pass

    async def _housekeeping(self) -> None:
        now = time.time()
        media.sweep()
        for job in self.store.list_jobs(("done", "partial", "failed", "cancelled"), 1000):
            age = now - (job.get("finished_at") or job["created_at"])
            if age > KEEP_FILES_FOR:
                for key in ("input_path", "output_path"):
                    if job.get(key) and os.path.exists(job[key]):
                        try:
                            os.remove(job[key])
                        except OSError:
                            pass
            if age > KEEP_JOBS_FOR:
                self.store.delete_job(job["id"])
        await self._refresh_tokens()

    async def _refresh_tokens(self) -> None:
        """Instagram long-lived tokens die after 60 days; renew them weekly so they never do."""
        from instagram.poster import refresh_token
        for acc in channel_manager.get_ig_accounts():
            if not channel_manager.is_ready("ig", acc):
                continue
            last = acc.get("refreshed_at")
            if last is None:                       # first sighting: start the clock, don't hammer the API
                channel_manager.update_account("ig", acc["id"], refreshed_at=time.time() - 6 * 86400)
                continue
            if time.time() - last < 7 * 86400:
                continue
            try:
                await refresh_token(acc)
                log.info("Refreshed Instagram token for %s", acc["name"])
            except Exception as e:
                channel_manager.update_account("ig", acc["id"], refreshed_at=time.time() - 6 * 86400)
                await self.notify(f"⚠️ Could not renew the Instagram token for {acc['name']}: {e}\n"
                                  f"Paste a fresh token in Accounts before it expires.")


def public_job(job: dict) -> dict:
    """Job as shown to the dashboard (no file paths)."""
    keep = ("id", "status", "run_at", "created_at", "finished_at", "source", "logo", "ending", "rule",
            "episode", "caption_mode", "caption_engine", "progress", "message", "error")
    out = {k: job.get(k) for k in keep}
    out["targets"] = [{k: t.get(k) for k in ("type", "id", "name", "status", "url", "error", "attempts", "caption")}
                      for t in job["targets"]]
    out["when"] = fmt_time(job.get("run_at")) if job["status"] == "scheduled" else ""
    out["downloadable"] = bool(job.get("output_path")) and os.path.exists(job.get("output_path") or "")
    return out
