"""Start everything: Telegram bot + dashboard + scheduler, in one process sharing one queue."""
import asyncio
import logging
import signal

import config
from pipeline import Pipeline

logging.basicConfig(format="%(asctime)s [%(levelname)s] %(name)s: %(message)s", level=logging.INFO)
logging.getLogger("httpx").setLevel(logging.WARNING)
log = logging.getLogger("videobot")


async def main() -> None:
    pipeline = Pipeline()
    engine = asyncio.create_task(pipeline.run_forever())

    bot = None
    if config.BOT_TOKEN and config.OWNER_ID:
        from bot import Bot
        bot = Bot(pipeline)
        await bot.start()
    else:
        log.warning("BOT_TOKEN / OWNER_ID not set — running the dashboard only.")

    try:
        if config.DASH_ENABLED:
            import uvicorn
            from dashboard.app import create_app
            server = uvicorn.Server(uvicorn.Config(
                create_app(pipeline), host=config.DASH_HOST, port=config.DASH_PORT, log_level="warning"))
            log.info("Dashboard listening on %s:%d", config.DASH_HOST, config.DASH_PORT)
            await server.serve()                     # returns on Ctrl+C / SIGTERM
        else:
            stop = asyncio.Event()
            for sig in (signal.SIGINT, signal.SIGTERM):
                asyncio.get_running_loop().add_signal_handler(sig, stop.set)
            await stop.wait()
    finally:
        engine.cancel()
        if bot:
            await bot.stop()
        log.info("Stopped. Queued videos are saved and resume on the next start.")


if __name__ == "__main__":
    asyncio.run(main())
