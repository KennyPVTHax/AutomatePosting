# VideoBot v7: private GitHub source and VPS clone

**Status: staging only. Do not expose to the Internet until OAuth, authentication, and security checks are complete.**

## Publish once from a trusted terminal

1. Download and extract the ZIP. Open a terminal in the `videobot` directory.
2. Authenticate GitHub CLI (`gh auth login`); the GitHub account must be able to create private repos.
3. Run `./publish_to_github.sh KennyPVTHax/videobot-v7`.
4. Confirm the GitHub repository is **Private** and the source files are visible.

No secrets should be pushed. `.gitignore` excludes `.env`, `channels.json`, credentials, tokens, video storage and runtime data. Review staged files and use a secret scanner before first push. The publish script will not replace an existing unrelated repository.

## Clone on the VPS (one command after SSH auth works)

```bash
git clone git@github.com:KennyPVTHax/videobot-v7.git /opt/videobot-v7
```

For a private repository, register a **read-only SSH deploy key** on GitHub and provide the matching private key securely on the VPS (never paste it into chat). If using an existing SSH key, ensure it grants access to this repo. A separate key for this repo is preferred.

**Cloning does NOT start or deploy the app.** Do not run legacy `setup.sh`: it overwrites the old VideoBot Nginx/service configuration. Review `V7_DEPLOYMENT.md` and deploy only after application hardening and HTTPS setup.

## Update source on the VPS

```bash
cd /opt/videobot-v7 && git pull --ff-only
```

Only source is version-controlled. Preserve `.env`, `channels.json`, uploads, databases, custom logos and generated videos in separately backed-up storage. `git pull` should not automatically restart a live process; deploy via a reviewed workflow with tests and rollback.
