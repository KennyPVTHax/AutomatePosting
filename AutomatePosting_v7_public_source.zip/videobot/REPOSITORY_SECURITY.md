# GitHub preservation: AutomatePosting

**Target:** `KennyPVTHax/AutomatePosting` — must be **Private** before pushing any source.

The publish script refuses a public repository. In GitHub, use Settings → General → Danger Zone → Change repository visibility → Make private.

1. Install `git` and `gh` and use `gh auth login` on a trusted machine.
2. Extract this archive, enter `videobot`, and run `bash publish_to_github.sh KennyPVTHax/AutomatePosting`.
3. Confirm the pushed commit and GitHub Actions results before configuring the VPS.
4. On the VPS, after configuring an SSH deploy key with read-only repository access: `git clone git@github.com:KennyPVTHax/AutomatePosting.git /opt/videobot-v7`.

Do not commit `.env`, account tokens, platform OAuth secrets, video uploads or other runtime data. A private repository does not replace encryption or proper secret handling. Never run the old `setup.sh` on the shared VPS. The code remains staging-only and is **not yet safe for public deployment**.
