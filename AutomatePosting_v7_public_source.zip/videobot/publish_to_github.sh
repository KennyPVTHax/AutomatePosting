#!/usr/bin/env bash
# Publishes source to the designated GitHub repository (PUBLIC is permitted).
set -euo pipefail
cd "$(dirname "$0")"
REPO="${1:-KennyPVTHax/AutomatePosting}"
command -v gh >/dev/null || { echo "Install GitHub CLI: https://cli.github.com/"; exit 1; }
command -v git >/dev/null || { echo "Install git"; exit 1; }
gh auth status >/dev/null || { echo "Run gh auth login first"; exit 1; }
# Verify repo identity and visibility explicitly before publishing.
if ! gh repo view "$REPO" --json nameWithOwner --jq '.nameWithOwner' | grep -Fxq "$REPO"; then
  echo "ABORTED: cannot access intended repo $REPO" >&2
  exit 1
fi
visibility="$(gh repo view "$REPO" --json visibility --jq '.visibility')"
echo "Publishing to $REPO (visibility: $visibility). This source will be public if visibility=PUBLIC."
if [[ ! -d .git ]]; then git init -b main; fi
# Refuse to publish sensitive files if mistakenly tracked.
git add -A
echo 'Review the files scheduled for commit:'
git diff --cached --name-only
if git diff --cached --name-only | grep -Ei '(^|/)(\.env($|\.(local|production|development|test)$)|channels\.json|client_secret[^/]*\.json|token\.json|tokens/|data/|assets/|venv/|\.venv/)|\.(pem|key)$' ; then
  echo 'ABORTED: possible private configuration or data staged' >&2; exit 1
fi
if ! git diff --cached --quiet; then git -c user.name="VideoBot Maintainer" -c user.email="videobot-maintainer@users.noreply.github.com" commit -m "Preserve VideoBot v7 staging baseline"; fi
if git remote get-url origin >/dev/null 2>&1; then
  if [[ "$(git remote get-url origin)" != "https://github.com/$REPO.git" ]]; then
    echo "ABORTED: origin is not the intended repository" >&2; exit 1
  fi
else
  git remote add origin "https://github.com/$REPO.git"
fi
git push -u origin main
echo "Repository: https://github.com/$REPO"
