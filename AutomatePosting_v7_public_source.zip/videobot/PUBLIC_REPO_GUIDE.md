# AutomatePosting public repository

Repository: https://github.com/KennyPVTHax/AutomatePosting

**Public source only.** Never commit `.env`, tokens, bot passwords, private OAuth JSON, database files, or user videos.

This is **v7 staging source**, not a production release. URLs supported by downloaders do not guarantee platform permissions.

On the server, after placing the archive in `/root`, run:

```bash
mkdir -p /root/automateposting-source
unzip -q /root/AutomatePosting_v7_public_source.zip -d /root/automateposting-source
cd /root/automateposting-source/videobot
bash publish_to_github.sh KennyPVTHax/AutomatePosting
```

Authenticate `gh auth login` first, with repository write permission. Do not upload `.env` or credential files.

Cloning after push (requires Git access):

```bash
git clone https://github.com/KennyPVTHax/AutomatePosting.git /opt/AutomatePosting
```

Do not run `setup.sh` on the shared VPS: it may change Nginx defaults. Test in staging and deploy using the isolated v7 service instead.
