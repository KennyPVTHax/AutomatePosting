"""Central config: paths + environment. Loads .env itself so `python run.py` just works."""
import os
import secrets

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def _load_env(path: str) -> None:
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, val = line.split("=", 1)
            val = val.strip()
            if val[:1] in "\"'" and val[-1:] == val[:1] and len(val) >= 2:
                val = val[1:-1]
            elif " #" in val:                     # strip trailing inline comment
                val = val.split(" #", 1)[0].strip()
            os.environ.setdefault(key.strip(), val)


_load_env(os.path.join(BASE_DIR, ".env"))


def _env(name: str, default: str = "") -> str:
    return os.environ.get(name, default).strip()


BOT_TOKEN        = _env("BOT_TOKEN")
OWNER_ID         = int(_env("OWNER_ID", "0") or 0)
TELEGRAM_API_URL = _env("TELEGRAM_API_URL")        # optional self-hosted Bot API (lifts the 20 MB limit)

GEMINI_API_KEY = _env("GEMINI_API_KEY")
GEMINI_MODEL   = _env("GEMINI_MODEL", "gemini-3.8-flash")

VPS_PUBLIC_URL = _env("VPS_PUBLIC_URL").rstrip("/")
TIMEZONE       = _env("TIMEZONE", "Asia/Kolkata")

DASH_HOST    = _env("DASH_HOST", "127.0.0.1")
DASH_PORT    = int(_env("DASH_PORT", "8090"))
DASH_ENABLED = _env("DASH_ENABLED", "1") not in ("0", "false", "no")

FFMPEG_PRESET = _env("FFMPEG_PRESET", "veryfast")
FFMPEG_CRF    = _env("FFMPEG_CRF", "18")
SPEED         = float(_env("SPEED", "1.02"))

DATA_DIR    = os.path.join(BASE_DIR, "data")
UPLOAD_DIR  = os.path.join(DATA_DIR, "uploads")
OUTPUT_DIR  = os.path.join(DATA_DIR, "outputs")
ASSETS_DIR  = os.path.join(BASE_DIR, "assets")
LOGOS_DIR   = os.path.join(ASSETS_DIR, "logos")
ENDINGS_DIR = os.path.join(ASSETS_DIR, "endings")
DB_PATH     = os.path.join(DATA_DIR, "videobot.db")
CHANNELS_FILE = os.path.join(BASE_DIR, "channels.json")

for _d in (DATA_DIR, UPLOAD_DIR, OUTPUT_DIR, LOGOS_DIR, ENDINGS_DIR):
    os.makedirs(_d, exist_ok=True)


def _serve_dir() -> str:
    """Folder whose files are publicly reachable at {VPS_PUBLIC_URL}/videos/ (Instagram fetches from it)."""
    wanted = _env("SERVE_DIR", "/var/www/html/videos")
    try:
        os.makedirs(wanted, exist_ok=True)
        if os.access(wanted, os.W_OK):
            return wanted
    except OSError:
        pass
    fallback = os.path.join(DATA_DIR, "public")
    os.makedirs(fallback, exist_ok=True)
    return fallback


SERVE_DIR = _serve_dir()


def _dash_password() -> str:
    pw = _env("DASH_PASSWORD")
    if pw:
        return pw
    path = os.path.join(DATA_DIR, "dash_password.txt")
    if os.path.exists(path):
        return open(path).read().strip()
    pw = secrets.token_urlsafe(9)
    with open(path, "w") as f:
        f.write(pw)
    os.chmod(path, 0o600)
    return pw


DASH_PASSWORD = _dash_password()

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp"}
VIDEO_EXTS = {".mp4", ".mov", ".webm", ".gif", ".mkv"}


def safe_name(name: str, default: str = "file") -> str:
    """Filename with no path parts or odd characters."""
    name = os.path.basename(name or "").replace(" ", "_")
    name = "".join(c for c in name if c.isalnum() or c in "._-")
    return name.lstrip(".") or default


def list_assets(kind: str) -> list[str]:
    directory = LOGOS_DIR if kind == "logo" else ENDINGS_DIR
    allowed = IMAGE_EXTS if kind == "logo" else IMAGE_EXTS | VIDEO_EXTS
    return sorted(f for f in os.listdir(directory)
                  if os.path.splitext(f)[1].lower() in allowed)


def asset_path(kind: str, name: str) -> str | None:
    if not name:
        return None
    directory = LOGOS_DIR if kind == "logo" else ENDINGS_DIR
    path = os.path.join(directory, safe_name(name))
    return path if os.path.isfile(path) else None
