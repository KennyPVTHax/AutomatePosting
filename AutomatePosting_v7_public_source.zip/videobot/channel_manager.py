"""
Accounts live in channels.json (same format as before, so your existing file drops in).
Writes are atomic and locked, so the bot and dashboard can't corrupt it.
"""
import json
import os
import threading

import config

_lock = threading.RLock()
KEYS = {"yt": "youtube", "ig": "instagram", "fb": "facebook"}
LABEL = {"yt": "YouTube", "ig": "Instagram", "fb": "Facebook"}
EMOJI = {"yt": "▶️", "ig": "📸", "fb": "🔵"}


def load_channels() -> dict:
    with _lock:
        data = {}
        if os.path.exists(config.CHANNELS_FILE):
            with open(config.CHANNELS_FILE, encoding="utf-8") as f:
                data = json.load(f)
        for key in KEYS.values():
            data.setdefault(key, [])
        return data


def _save(data: dict) -> None:
    with _lock:
        tmp = config.CHANNELS_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp, config.CHANNELS_FILE)
        try:
            os.chmod(config.CHANNELS_FILE, 0o600)
        except OSError:
            pass


def make_id(name: str) -> str:
    slug = "".join(c if c.isalnum() else "_" for c in name.lower()).strip("_")
    return slug[:32] or "account"


def get_yt_channels() -> list: return load_channels()["youtube"]
def get_ig_accounts() -> list: return load_channels()["instagram"]
def get_fb_accounts() -> list: return load_channels()["facebook"]


def get_account(kind: str, acc_id: str) -> dict | None:
    return next((a for a in load_channels()[KEYS[kind]] if a["id"] == acc_id), None)


def flat_accounts() -> list[dict]:
    """Every account as {key:'yt:id', type, id, name, ready} — no secrets."""
    data, out = load_channels(), []
    for kind, key in KEYS.items():
        for a in data[key]:
            out.append({"key": f"{kind}:{a['id']}", "type": kind, "id": a["id"],
                        "name": a.get("name", a["id"]), "ready": is_ready(kind, a),
                        "paired_ig": a.get("paired_ig", ""), "paired_fb": a.get("paired_fb", "")})
    return out


def is_ready(kind: str, acc: dict) -> bool:
    if kind == "yt":
        return os.path.exists(os.path.join(config.BASE_DIR, acc.get("token_file", "")))
    token = acc.get("access_token", "")
    return bool(token) and not token.upper().startswith("YOUR_")


def _upsert(kind: str, acc_id: str, fields: dict) -> str:
    with _lock:
        data = load_channels()
        for a in data[KEYS[kind]]:
            if a["id"] == acc_id:
                a.update(fields)
                _save(data)
                return "updated"
        data[KEYS[kind]].append({"id": acc_id, **fields})
        _save(data)
        return "added"


def add_yt_channel(channel_id: str, name: str, client_secret_path: str) -> str:
    return _upsert("yt", channel_id, {
        "name": name, "token_file": f"youtube/tokens/{channel_id}.json",
        "client_secret": client_secret_path})


def add_ig_account(account_id: str, name: str, access_token: str, user_id: str) -> str:
    return _upsert("ig", account_id, {"name": name, "access_token": access_token, "user_id": user_id})


def add_fb_account(account_id: str, name: str, page_id: str, access_token: str) -> str:
    return _upsert("fb", account_id, {"name": name, "page_id": page_id, "access_token": access_token})


def update_account(kind: str, acc_id: str, **fields) -> None:
    with _lock:
        data = load_channels()
        for a in data[KEYS[kind]]:
            if a["id"] == acc_id:
                a.update(fields)
        _save(data)


def pair(yt_id: str, ig_id: str = "", fb_id: str = "") -> None:
    fields = {}
    if ig_id: fields["paired_ig"] = ig_id
    if fb_id: fields["paired_fb"] = fb_id
    if fields:
        update_account("yt", yt_id, **fields)


def remove_account(kind: str, acc_id: str) -> None:
    with _lock:
        data = load_channels()
        data[KEYS[kind]] = [a for a in data[KEYS[kind]] if a["id"] != acc_id]
        _save(data)
