# VideoBot v7: Import from URL + per-video editing

## Implemented in source (not yet deployed)

- Existing browser file upload and posting pipeline preserved.
- New browser link import for public YouTube, Instagram or Facebook video URLs.
- Server imports via `yt-dlp`, with a strict initial HTTPS host allowlist, one concurrent download, 15-minute process timeout, 1.5 GiB size cap, and no stored browser cookies.
- Import status polling and owner-authenticated preview; a completed import can be handed off to the regular job scheduler.
- Per-video FFmpeg speed (0.75–1.50x) and subtle contrast (0.98–1.04x; default 1.01).
- Toggle logo watermark and optional image/video ending; logo placement can be top-right, top-left, bottom-right or bottom-left. Existing logo/ending assets upload through Library.
- FFmpeg capped to two threads; existing scheduling, AI captions and targets remain.

## Important caveats

Only import material you own or have authorization to download and republish. URLs that require login, cookies, DRM bypass or unsupported provider extraction may fail. Platform rules and permissions still apply. No credentials/cookies are supplied to the downloader. This is not a guarantee that all links will work.

This is a **source-level implementation, not a production release**. Full integrated HTTP tests, mobile browser QA, downloader integration against platforms, and live upload/publishing tests have not been completed. Private-site restrictions and platform API limitations can change.

The current import queue/status is in process memory. Restarting the app during a link download loses the import record; a future upgrade should persist import records, use a dedicated worker, maintain lifecycle cleanup and provide progress estimates. There is no resumable HTTP upload support yet.

## Install prerequisites for a future authorized staging deployment

Use a new isolated virtual environment; never run the legacy `setup.sh` because it would overwrite existing VideoBot/Nginx components. Install dependencies from `requirements.txt` including yt-dlp. FFmpeg + ffprobe must be installed.

HTTPS and domain/callback routing are separate from this feature. Do not expose the staging service publicly until login/session/CSRF/secret protections are audited.
